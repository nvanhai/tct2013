-- Start of DDL Script for Table QLT_OWNER.RCV_TKHAI_HDR
-- Generated 20-Feb-2006 10:25:39 from QLT_OWNER@QLT_91

CREATE TABLE rcv_tkhai_hdr
    (id                             NUMBER(10,0) NOT NULL,
    tin                            VARCHAR2(14) NOT NULL,
    ten_dtnt                       VARCHAR2(100) NOT NULL,
    dia_chi                        VARCHAR2(60),
    loai_tkhai                     VARCHAR2(2),
    ngay_nop                       DATE,
    kylb_tu_ngay                   DATE,
    kylb_den_ngay                  DATE,
    kykk_tu_ngay                   DATE,
    kykk_den_ngay                  DATE,
    ngay_cap_nhat                  DATE,
    nguoi_cap_nhat                 VARCHAR2(60),
    co_loi_ddanh                   CHAR(1),
    so_hieu_tep                    VARCHAR2(20),
    so_tt_tk                       NUMBER(10,0),
    da_nhan                        CHAR(1),
    ghi_chu_loi                    VARCHAR2(100),
    co_gtrinh_02a                  CHAR(1),
    co_gtrinh_02b                  CHAR(1),
    co_gtrinh_02c                  CHAR(1),
    khoa_so                        VARCHAR2(1),
    tu_ngay                        DATE,
    den_ngay                       DATE)
/

-- Constraints for RCV_TKHAI_HDR


ALTER TABLE rcv_tkhai_hdr
ADD CONSTRAINT rcv_tkh_pk PRIMARY KEY (id)
USING INDEX
/


-- End of DDL Script for Table QLT_OWNER.RCV_TKHAI_HDR

-- Foreign Key
ALTER TABLE rcv_tkhai_hdr
ADD CONSTRAINT rcv_tkh_fk FOREIGN KEY (loai_tkhai)
REFERENCES rcv_dm_tkhai (ma)
/
-- End of DDL script for Foreign Key(s)
