DELETE FROM rcv_thamso
/
INSERT INTO rcv_thamso
VALUES
('THEO_NAM_TAICHINH','0','0 - false, 1 - true')
/
INSERT INTO rcv_thamso
VALUES
('LOAI_TK_TAICHINH','02,03','Ma cac loai to khai can kiem tra ngay bat dau nam tai chinh')
/
