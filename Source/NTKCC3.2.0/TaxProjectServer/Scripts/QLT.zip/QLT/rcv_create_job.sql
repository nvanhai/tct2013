BEGIN
    rcv_pck_job.prc_run_job('rcv_pck_chuyen_dlieu_qlt.prc_chuyen_dlieu_qlt;');
END;
/
