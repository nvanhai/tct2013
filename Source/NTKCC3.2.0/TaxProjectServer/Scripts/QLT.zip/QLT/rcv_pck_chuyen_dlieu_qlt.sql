-- Start of DDL Script for Package Body QLT_OWNER.RCV_PCK_CHUYEN_DLIEU_QLT
-- Generated 3/9/2006 5:09:13 PM from QLT_OWNER@QLT_91

CREATE OR REPLACE 
PACKAGE rcv_pck_chuyen_dlieu_qlt IS
/*******************************************************************************
Phien ban: 1.0
Nguoi lap: Nguyen Ta Anh
Ngay lap: 15/11/2005
Muc dich: Do du lieu tu CSDL trung gian sau khi quet to khai vao QLT
*******************************************************************************/
  TYPE Record_Hdr IS RECORD(id NUMBER(10,0),
                            tin VARCHAR2(14),
                            ten_dtnt VARCHAR2(60),
                            dia_chi VARCHAR2(60),
                            loai_tkhai VARCHAR2(2),
                            loai VARCHAR2(2),
                            ngay_nop DATE,
                            kylb_tu_ngay DATE,
                            kylb_den_ngay DATE,
                            kykk_tu_ngay DATE,
                            kykk_den_ngay DATE,
                            ngay_cap_nhat DATE,
                            nguoi_cap_nhat VARCHAR2(60),
                            co_loi_ddanh CHAR(1),
                            so_hieu_tep VARCHAR(20),
                            so_tt_tk NUMBER(10,0),
                            ghi_chu_loi VARCHAR(100),
                            co_gtrinh_02a CHAR(1),
                            co_gtrinh_02b CHAR(1),
                            co_gtrinh_02c CHAR(1));
/******************************************************************************/
  TYPE Record_Dtnt IS RECORD(tin VARCHAR2(14),
                             ten_dtnt VARCHAR2(60),
                             dia_chi VARCHAR2(60),
                             ma_cqt VARCHAR2(5),
                             ma_tinh VARCHAR2(3),
                             ma_huyen VARCHAR2(5),
                             ma_phong VARCHAR2(7),
                             ma_canbo VARCHAR2(10),
                             ma_cap VARCHAR2(1),
                             ma_chuong VARCHAR2(3),
                             ma_loai VARCHAR2(2),
                             ma_khoan VARCHAR2(2),
                             trang_thai VARCHAR2(2),
                             dien_thoai VARCHAR2(20),
                             fax VARCHAR2(20),
                             email VARCHAR2(30),
                             ngay_kdoanh DATE,
                             ngay_tchinh DATE,
                             loai VARCHAR2(2));
/******************************************************************************/
  PROCEDURE Prc_Chuyen_Dlieu_Qlt;
/******************************************************************************/
  FUNCTION Fnc_TKhai_Exits(p_Tin VARCHAR2,
                           p_Loai_TKhai VARCHAR2,
                           p_Kykk_Tu_Ngay DATE,
                           p_Kykk_Den_Ngay DATE,
                           p_Tthai OUT VARCHAR2,
                           p_Loai VARCHAR2) RETURN NUMBER;
/******************************************************************************/
  FUNCTION Fnc_Lay_So_Ktru_Ktruoc(p_Tin VARCHAR2,
                                  p_Kylb DATE) RETURN NUMBER;
/******************************************************************************/
  PROCEDURE Prc_TKhai_GTGT(p_Record_Of_Header Record_Hdr,
                           p_Record_Dtnt Record_Dtnt,
                           p_TKhai_Exits_Id NUMBER,
                           p_Tthai_Tkhai VARCHAR2);
/******************************************************************************/
  PROCEDURE Prc_TKhai_TNDN_Quy(p_Record_Of_Header Record_Hdr,
                               p_Record_Dtnt Record_Dtnt,
                               p_TKhai_Exits_Id NUMBER,
                               p_Tthai_Tkhai VARCHAR2);
/******************************************************************************/
  PROCEDURE Prc_Thong_Tin_Dtnt(p_Tin VARCHAR2,
                               p_Record_Dtnt OUT Record_Dtnt);
/******************************************************************************/
  FUNCTION Fnc_AnDinh_Exits(p_Tin VARCHAR2,
                            p_Loai_TKhai VARCHAR2,
                            p_Kykk_Tu_Ngay DATE,
                            p_Kykk_Den_Ngay DATE) RETURN BOOLEAN;
/******************************************************************************/
  PROCEDURE Prc_TKhai_QToan_TNDN_Nam(p_Record_Of_Header Record_Hdr,
                                     p_Record_Dtnt Record_Dtnt,
                                     p_TKhai_Exits_Id NUMBER,
                                     p_Tthai_Tkhai VARCHAR2);
/******************************************************************************/
  FUNCTION Fnc_So_KKhai_TKhai (p_Tin VARCHAR2,
    						   p_Tmt_Ma_Muc VARCHAR2,
    						   p_Tmt_Ma_TMuc VARCHAR2,
    						   p_Tmt_Ma_Thue VARCHAR2,
    						   p_KyKK DATE) RETURN NUMBER;
/******************************************************************************/
  FUNCTION Fnc_Han_Nop(p_Ma_TKhai VARCHAR2,
                       p_Loai VARCHAR2,
                       p_Cuoi_Ky DATE,
                       p_Nam_TChinh DATE DEFAULT NULL) RETURN DATE;
/******************************************************************************/
END;
/

CREATE OR REPLACE 
PACKAGE BODY rcv_pck_chuyen_dlieu_qlt IS
/******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 16/11/2005
Muc dich: Thuc hien kiem tra to khai hay quyet toan da ton tai trong QLT chua,
          ung voi mot ky ke khai
Tham so:
     - p_Tin: Ma so thue cua DTNT
     - p_Loai_TKhai: Ma to khai
     - p_Kykk_Tu_Ngay: Ky ke khai tu ngay
     - p_Kykk_Den_Ngay: Ky ke khai den ngay
     - p_Tthai: Trang thai tra ve
     - p_Loai: To khai hay quyet toan
*******************************************************************************/
    FUNCTION Fnc_TKhai_Exits(p_Tin VARCHAR2,
                             p_Loai_TKhai VARCHAR2,
                             p_Kykk_Tu_Ngay DATE,
                             p_Kykk_Den_Ngay DATE,
                             p_Tthai OUT VARCHAR2,
                             p_Loai VARCHAR2) RETURN NUMBER IS
        CURSOR c_TKhai_Exits IS
            SELECT hdr.id, hdr.tthai
            FROM qlt_tkhai_hdr hdr
            WHERE (hdr.tin = p_Tin)
              AND (hdr.dtk_ma_loai_tkhai = p_Loai_TKhai)
              AND (hdr.kykk_tu_ngay = p_Kykk_Tu_Ngay)
              AND (hdr.kykk_den_ngay = p_Kykk_Den_Ngay)
              AND (hdr.ltd = 0);
        vc_TKhai_Exits c_TKhai_Exits%ROWTYPE;
        
        CURSOR c_QToan_Exits IS
            SELECT hdr.id, hdr.tthai
            FROM qlt_qtoan_hdr hdr
            WHERE (hdr.tin = p_Tin)
              AND (hdr.dqt_ma = p_Loai_TKhai)
              AND (hdr.kykk_tu_ngay = p_Kykk_Tu_Ngay)
              AND (hdr.kykk_den_ngay = p_Kykk_Den_Ngay)
              AND (hdr.ltd = 0);
        vc_QToan_Exits c_QToan_Exits%ROWTYPE;
        
    BEGIN
        --Xu ly voi to khai
        IF (p_Loai = 'TK') THEN
            OPEN c_TKhai_Exits;
            FETCH c_TKhai_Exits INTO vc_TKhai_Exits;
            IF (c_TKhai_Exits%FOUND) THEN
                p_Tthai := vc_TKhai_Exits.tthai;
                RETURN vc_TKhai_Exits.id;
            ELSE
                RETURN NULL;
            END IF;
            CLOSE c_TKhai_Exits;
        --Xu ly voi quyet toan
        ELSIF (p_Loai = 'QT') THEN
            OPEN c_QToan_Exits;
            FETCH c_QToan_Exits INTO vc_QToan_Exits;
            IF (c_QToan_Exits%FOUND) THEN
                p_Tthai := vc_QToan_Exits.tthai;
                RETURN vc_QToan_Exits.id;
            ELSE
                RETURN NULL;
            END IF;
            CLOSE c_QToan_Exits;
        END IF;
    END;
/******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 16/01/2006
Muc dich: Thuc hien kiem tra an dinh da ton tai trong QLT chua,
          ung voi mot ky ke khai
Tham so:
     - p_Tin: Ma so thue cua DTNT
     - p_Loai_TKhai: Loai to khai cua DTNT nop
     - p_KyKK: Ky ke khai ma DTNT nop to khai
*******************************************************************************/
    FUNCTION Fnc_AnDinh_Exits(p_Tin VARCHAR2,
                              p_Loai_TKhai VARCHAR2,
                              p_Kykk_Tu_Ngay DATE,
                              p_Kykk_Den_Ngay DATE) RETURN BOOLEAN IS
        CURSOR c_AnDinh_Exist IS
            SELECT 1
            FROM qlt_ds_an_dinh_hdr hdr
            WHERE (hdr.tin = p_Tin)
              AND (hdr.dtk_ma = p_Loai_TKhai)
              AND (hdr.kykk_tu_ngay = p_Kykk_Tu_Ngay)
              AND (hdr.kykk_den_ngay = p_Kykk_Den_Ngay);
        v_Found_AnDinh BOOLEAN := FALSE;
        test number;
    BEGIN
        OPEN c_AnDinh_Exist; /*Kiem tra da co an dinh chua*/
        FETCH c_AnDinh_Exist INTO test;
        IF (c_AnDinh_Exist%FOUND) THEN
            v_Found_AnDinh := TRUE;
        END IF;
        CLOSE c_AnDinh_Exist;
        RETURN v_Found_AnDinh;
    END;
/*******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 16/11/2005
Muc dich: Thuc hien lay so khau tru ky truoc (trong so thue) cua ky ke khai
          hien tai
Tham so:
        - p_Tin: Ma so thue cua DTNT
        - p_Kylb: Ky lap bo cua co quan thue
*******************************************************************************/
    FUNCTION Fnc_Lay_So_Ktru_Ktruoc(p_Tin VARCHAR2,
                                    p_Kylb DATE) RETURN NUMBER IS
        v_Ktru NUMBER(20,2);
    BEGIN
        SELECT SUM(ktru_dky) INTO v_Ktru
		FROM qlt_so_thue
		WHERE (tin = p_Tin)
		  AND (kylb_tu_ngay = TRUNC(p_Kylb,'MONTH'))
		  AND (kylb_den_ngay = LAST_DAY(p_Kylb))
		  AND (tmt_ma_muc = '014')
		  AND (tmt_ma_tmuc = '01');
        IF (v_Ktru < 0) THEN
            v_Ktru := 0;
        END IF;
		RETURN ROUND(NVL(v_Ktru,0));
    END;
/*******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 19/01/2006
Muc dich: Thuc hien lay so ke khai cua DTNT trong 12 thang
Tham so:
        - p_Tin: Ma so thue cua DTNT
        - p_Tmt_Ma_Muc: Ma muc
        - p_Tmt_Ma_TMuc: Ma tieu muc
        - p_Tmt_Ma_Thue: Ma thue
        - p_KyKK: Ky ke khai
*******************************************************************************/
    FUNCTION Fnc_So_KKhai_TKhai (p_Tin VARCHAR2,
    							 p_Tmt_Ma_Muc VARCHAR2,
    							 p_Tmt_Ma_TMuc VARCHAR2,
    							 p_Tmt_Ma_Thue VARCHAR2,
    							 p_KyKK DATE) RETURN NUMBER IS
      --Lay tong so thue tam nop tren to khai TNDN nam
    	CURSOR c_Thue_Tam_Nop IS
    		SELECT SUM(DECODE(dgd_ma_gdich, 58, (-1) * NVL(so_tien,0), NVL(so_tien,0)))
    		FROM qlt_xltk_gdich
    		WHERE (tin = p_Tin)
    		  AND (tmt_ma_muc = p_Tmt_Ma_Muc)
    		  AND (tmt_ma_tmuc = p_Tmt_Ma_TMuc)
    		  AND (tmt_ma_thue = p_Tmt_Ma_Thue)
    		  AND (dgd_kieu_gdich IN ('21','25')) --Kieu giao dich va
    		  AND (dgd_ma_gdich IN ('04','16','20','78','22','24','58')) -- ma giao dich
    		  AND (kykk_tu_ngay >= TRUNC(p_KyKK, 'RRRR'))
    		  AND (kykk_den_ngay <= TO_DATE('31/12/' || TO_CHAR(p_KyKK,'RRRR'),'DD/MM/RRRR'));

        --Lay tong so thue tam nop tren to khai TNDN thang
        CURSOR c_Thue_Tam_Nop_Thang IS
        	SELECT SUM(DECODE(dgd_ma_gdich, 58, (-1) * NVL(so_tien,0), NVL(so_tien,0)))
        	FROM qlt_xltk_gdich
        	WHERE (tin = p_Tin)
        	  AND (tmt_ma_muc = p_Tmt_Ma_Muc)
        	  AND (tmt_ma_tmuc = p_Tmt_Ma_TMuc)
        	  AND (tmt_ma_thue = p_Tmt_Ma_Thue)
        	  AND (dgd_kieu_gdich IN ('21','25')) --Kieu giao dich va
        	  AND (dgd_ma_gdich IN ('06','12','18','22','24','58')) -- ma giao dich
        	  AND (kykk_tu_ngay >= TRUNC(p_KyKK, 'RRRR'))
        	  AND (kykk_den_ngay <= TO_DATE('31/12/' || TO_CHAR(p_KyKK,'RRRR'),'DD/MM/RRRR'));

    	vc_Thue_Tam_Nop	NUMBER;
    	vc_Thue_TBao NUMBER;
    	vc_Thue_Tam_Nop_Thang NUMBER;
    	v_So_KKhai_TKhai NUMBER;
    	v_Exist_TKhai_DChinh BOOLEAN;
    BEGIN
        --Lay so thue tam nop ca nam tren to khai TNDN nam
        OPEN c_Thue_Tam_Nop; --So thue tam nop tren to khai dieu chinh
        FETCH c_Thue_Tam_Nop INTO vc_Thue_Tam_Nop;
        CLOSE c_Thue_Tam_Nop;

        OPEN c_Thue_Tam_Nop_Thang; --So thue tam nop tren to khai TNDN thang
        FETCH c_Thue_Tam_Nop_Thang INTO vc_Thue_Tam_Nop_Thang;
        CLOSE c_Thue_Tam_Nop_Thang;

        --Tinh so ke khai tren to khai tam nop
        v_So_KKhai_TKhai := NVL(vc_Thue_Tam_Nop,0) + NVL(vc_Thue_Tam_Nop_Thang,0);
        RETURN(v_So_KKhai_TKhai);
    END;
/*******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 12/01/2006
Muc dich: Thuc hien lay thong tin cua DTNT
Tham so:
        - p_Tin: Ma so thue
        - p_Record_Of_Header: Bien ban ghi chua du lieu cua mot record
                              trong bang RCV_TKHAI_HDR
*******************************************************************************/
    PROCEDURE Prc_Thong_Tin_Dtnt(p_Tin VARCHAR2,
                                 p_Record_Dtnt OUT Record_Dtnt) IS
        CURSOR c_Dtnt IS
            SELECT *
            FROM rcv_v_dtnt dtnt
            WHERE (dtnt.tin = p_Tin);
        vc_Dtnt c_Dtnt%ROWTYPE;
    BEGIN
        OPEN c_Dtnt;
        FETCH c_Dtnt INTO vc_Dtnt;
        IF (c_Dtnt%FOUND) THEN
            p_Record_Dtnt.tin := vc_Dtnt.tin;
            p_Record_Dtnt.ten_dtnt := vc_Dtnt.ten_dtnt;
            p_Record_Dtnt.dia_chi := vc_Dtnt.dia_chi;
            p_Record_Dtnt.ma_cqt := vc_Dtnt.ma_cqt;
            p_Record_Dtnt.ma_tinh := vc_Dtnt.ma_tinh;
            p_Record_Dtnt.ma_huyen := vc_Dtnt.ma_huyen;
            p_Record_Dtnt.ma_canbo := vc_Dtnt.ma_canbo;
            p_Record_Dtnt.ma_cap := vc_Dtnt.ma_cap;
            p_Record_Dtnt.ma_chuong := vc_Dtnt.ma_chuong;
            p_Record_Dtnt.ma_loai := vc_Dtnt.ma_loai;
            p_Record_Dtnt.ma_khoan := vc_Dtnt.ma_khoan;
            p_Record_Dtnt.ngay_tchinh := vc_Dtnt.ngay_tchinh;
        END IF;
        CLOSE c_Dtnt;
    END;
/*******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 09/02/2006
Muc dich: Thuc hien lay han nop cua mot to khai hoac quyet toan
Tham so:
        - p_Ma_TKhai: Ma to khai
        - p_Loai: Loai to khai hay quyet toan
        - p_Cuoi_Ky: Ngay cuoi cua ky ke khai ung voi
                     tung loai to khai hay quyet toan
        - p_Nam_TChinh: Nam tai chinh cua DTNT
*******************************************************************************/
    FUNCTION Fnc_Han_Nop(p_Ma_TKhai VARCHAR2,
                         p_Loai VARCHAR2,
                         p_Cuoi_Ky DATE,
                         p_Nam_TChinh DATE DEFAULT NULL) RETURN DATE IS
        --Kiem tra co theo nam tai chinh hay khong
        CURSOR c_Nam_TChinh IS
            SELECT gia_tri
            FROM rcv_thamso
            WHERE (ten = 'THEO_NAM_TAICHINH');
        v_Nam_TChinh NUMBER;
        
        --Lay cac loai to khai tinh toan theo nam tai chinh
        CURSOR c_TKhai_TChinh IS
            SELECT gia_tri
            FROM rcv_thamso
            WHERE (ten = 'LOAI_TK_TAICHINH');
        v_TKhai_TChinh VARCHAR2(1000);
        
        --Kiem tra to khai dang xu ly co tinh toan theo nam tai chinh khong
        CURSOR c_TKhai_TChinh_Qlt IS
            SELECT ma_tkhai_qlt
            FROM rcv_map_tkhai
            WHERE INSTR(v_TKhai_TChinh, ma_tkhai) > 0
              AND (ma_tkhai_qlt = p_Ma_TKhai);

        --Tinh han nop to khai khong theo nam tai chinh
        CURSOR c_HanNop_TKhai IS
            SELECT ADD_MONTHS(p_Cuoi_Ky,1) han_nop_tkhai
            FROM qlt_dm_tkhai
            WHERE (ma = p_Ma_TKhai);

        --Tinh han nop quyet toan khong theo nam tai chinh
        CURSOR c_HanNop_QToan IS
            SELECT ADD_MONTHS(p_Cuoi_Ky,TO_NUMBER(thang)) han_nop_qtoan
            FROM qlt_dm_qtoan
            WHERE (ma = p_Ma_TKhai);
            
        --Tinh han nop to khai theo nam tai chinh
        CURSOR c_HanNop_TKhai_TChinh IS
            SELECT DECODE(kieu_ky,'M',ADD_MONTHS(p_Cuoi_Ky,1)
                                 ,'Q',ADD_MONTHS(TRUNC(LAST_DAY(TO_DATE(TO_CHAR(p_Nam_TChinh,'DD/MM')||'/'||TO_CHAR(p_Cuoi_Ky,'RRRR'),'DD/MM/RRRR'))),TO_NUMBER(TO_CHAR(p_Cuoi_Ky,'Q')) * 3)
                                 ,'Y',ADD_MONTHS(TRUNC(LAST_DAY(TO_DATE(TO_CHAR(p_Nam_TChinh,'DD/MM')||'/'||TO_CHAR(p_Cuoi_Ky,'RRRR'),'DD/MM/RRRR'))),12)) han_nop_tkhai
            FROM qlt_dm_tkhai
            WHERE (ma = p_Ma_TKhai);

        --Tinh han nop quyet toan theo nam tai chinh
        CURSOR c_HanNop_QToan_TChinh IS
            SELECT ADD_MONTHS(LAST_DAY(TO_DATE(TO_CHAR(p_Nam_TChinh,'DD/MM')||'/'||TO_CHAR(p_Cuoi_Ky,'RRRR'),'DD/MM/RRRR')),TO_NUMBER(thang) + 11) han_nop_qtoan
            FROM qlt_dm_qtoan
            WHERE (ma = p_Ma_TKhai);
            
        v_HanNop DATE;
        v_TKhai_Khong_Nam_TChinh VARCHAR2(2);
        
    BEGIN
        OPEN c_Nam_TChinh;
        FETCH c_Nam_TChinh INTO v_Nam_TChinh;
        CLOSE c_Nam_TChinh;
        
        IF (v_Nam_TChinh = 1) THEN --Theo nam tai chinh
            IF (p_Loai = 'TK') THEN
                OPEN c_HanNop_TKhai;
                FETCH c_HanNop_TKhai INTO v_HanNop;
                CLOSE c_HanNop_TKhai;
            ELSIF (p_Loai = 'QT') THEN 
                OPEN c_HanNop_QToan;
                FETCH c_HanNop_QToan INTO v_HanNop;
                CLOSE c_HanNop_QToan;
            END IF;
        ELSIF (v_Nam_TChinh = 0) THEN --Khong theo nam tai chinh
            OPEN c_TKhai_TChinh;
            FETCH c_TKhai_TChinh INTO v_TKhai_TChinh;
            CLOSE c_TKhai_TChinh;
            
            FOR vc_TKhai_TChinh_Qlt IN c_TKhai_TChinh_Qlt LOOP
                IF (p_Loai = 'TK') THEN
                    OPEN c_HanNop_TKhai_TChinh;
                    FETCH c_HanNop_TKhai_TChinh INTO v_HanNop;
                    CLOSE c_HanNop_TKhai_TChinh;
                ELSIF (p_Loai = 'QT') THEN
                    OPEN c_HanNop_QToan_TChinh;
                    FETCH c_HanNop_QToan_TChinh INTO v_HanNop;
                    CLOSE c_HanNop_QToan_TChinh;
                END IF;
            END LOOP;
            
            SELECT ma_tkhai INTO v_TKhai_Khong_Nam_TChinh
            FROM rcv_map_tkhai
            WHERE (ma_tkhai_qlt = p_Ma_TKhai);
            
            IF (INSTR(v_TKhai_TChinh,v_TKhai_Khong_Nam_TChinh) = 0) THEN
                IF (p_Loai = 'TK') THEN
                    OPEN c_HanNop_TKhai;
                    FETCH c_HanNop_TKhai INTO v_HanNop;
                    CLOSE c_HanNop_TKhai;
                ELSIF (p_Loai = 'QT') THEN
                    OPEN c_HanNop_QToan;
                    FETCH c_HanNop_QToan INTO v_HanNop;
                    CLOSE c_HanNop_QToan;
                END IF;
            END IF;
        END IF;

        RETURN v_HanNop;
    END;
/*******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 17/11/2005
Muc dich: Thuc hien do du lieu to khai GTGT khau tru vao CSDL TKN_TC
Tham so:
        - p_Record_Of_Header: Bien ban ghi chua du lieu cua mot record
                              trong bang RCV_TKHAI_HDR
        - p_Record_Dtnt: Bien ban ghi chua thong tin DTNT
        - p_TKhai_Exits_Id: Id cua to khai da ton tai
        - p_Tthai_Tkhai: Trang thai cua to khai da ton tai
*******************************************************************************/
    PROCEDURE Prc_TKhai_GTGT(p_Record_Of_Header Record_Hdr,
                             p_Record_Dtnt Record_Dtnt,
                             p_TKhai_Exits_Id NUMBER,
                             p_Tthai_Tkhai VARCHAR2) IS
	    TYPE Record_Dtl_GTGT IS RECORD(id NUMBER(10,0),
                                  ctk_id NUMBER(10,0),
                                  so_tt NUMBER(3,0),
                                  doanhso_dtnt NUMBER(20,2),
                                  sothue_dtnt NUMBER(20,2),
                                  doanhso_cqt NUMBER(20,2),
                                  sothue_cqt NUMBER(20,2),
                                  ke_khai_sai VARCHAR2(1),
                                  ma_so_ct_thue VARCHAR2(5),
                                  ma_so_ct_doanhso VARCHAR2(5));
        TYPE Array_Of_Record_Dtl IS TABLE OF Record_Dtl_GTGT INDEX BY BINARY_INTEGER;
        v_Array_Of_Record_Dtl Array_Of_Record_Dtl;

        CURSOR c_TKhai_Dtl IS
            SELECT tkhai.ctk_id,
                   tkhai.so_tt,
                   DECODE(tkhai.ctk_id, 252,DECODE(tkhai.doanhso_dtnt, 'x', 1, 0), tkhai.doanhso_dtnt) doanhso_dtnt,
                   tkhai.sothue_dtnt,
                   tkhai.ky_hieu_ctieu_ds,
                   tkhai.ky_hieu_ctieu_st
            FROM rcv_v_tkhai_gtgt_kt tkhai
            WHERE (tkhai.hdr_id = p_Record_Of_Header.id)
            ORDER BY tkhai.ctk_id;
        vc_TKhai_Dtl c_TKhai_Dtl%ROWTYPE;

        v_Thue_Dau_Ra NUMBER(20,2);
        v_Thue_Dau_Vao NUMBER(20,2);
        v_Thue_KTru_KySau NUMBER(20,2);
        v_Thue_PSinh_KyNay NUMBER(20,2);
        v_Thue_KTru_KyNay NUMBER(20,2);
        v_Thue_PNop_KyNay NUMBER(20,2);
        v_Hdr_Id NUMBER(10,0);
        v_So_KTru NUMBER(20,2);
        v_PSinh_TKy NUMBER(20,2);
        v_Tthai_Tkhai VARCHAR2(1);
        v_Count NUMBER(10) := 0;
        v_Index NUMBER(10) := 0;
        v_Temp NUMBER(20,2) := 0;
        v_Nguong_Min NUMBER;
        v_Sai_SoHoc VARCHAR2(1) := NULL;
        v_HanNop DATE;

    BEGIN
        /*Xu ly voi du lieu to khai Detail*/
        FOR vc_TKhai_Dtl IN c_TKhai_Dtl LOOP
            /*Dua du lieu tu RCV_V_TKHAI_GTGT_KT ra mang de xu ly*/
            v_Count := v_Count + 1;
            SELECT qlt_xltk_dtl_seq.NEXTVAL INTO v_Array_Of_Record_Dtl(v_count).id
            FROM dual;
            v_Array_Of_Record_Dtl(v_Count).ctk_id := vc_TKhai_Dtl.ctk_id;
            v_Array_Of_Record_Dtl(v_Count).so_tt := vc_TKhai_Dtl.so_tt;
            v_Array_Of_Record_Dtl(v_Count).doanhso_dtnt := vc_TKhai_Dtl.doanhso_dtnt;
            v_Array_Of_Record_Dtl(v_Count).sothue_dtnt := vc_TKhai_Dtl.sothue_dtnt;
            v_Array_Of_Record_Dtl(v_Count).doanhso_cqt := vc_TKhai_Dtl.doanhso_dtnt;
            v_Array_Of_Record_Dtl(v_Count).sothue_cqt := vc_TKhai_Dtl.sothue_dtnt;
            v_Array_Of_Record_Dtl(v_Count).ke_khai_sai := NULL;
            v_Array_Of_Record_Dtl(v_Count).ma_so_ct_thue := vc_TKhai_Dtl.ky_hieu_ctieu_st;
            v_Array_Of_Record_Dtl(v_Count).ma_so_ct_doanhso := vc_TKhai_Dtl.ky_hieu_ctieu_ds;
        END LOOP;

        /*Thuc hien kiem tra ke khai sai voi cac chi tieu to khai*/
        /*********************************************************/

        /*Lay so khau ky truoc cua co quan thue, chi tieu 11*/
        v_Array_Of_Record_Dtl(2).sothue_cqt := Fnc_Lay_So_Ktru_Ktruoc(p_Record_Of_Header.tin,
                                                                      p_Record_Of_Header.kylb_tu_ngay);

       	--Chi Tieu [30]*5% - Nguong <= |[31]| <= [30]*5% + Nguong
        v_Temp := ROUND((v_Array_Of_Record_Dtl(18).doanhso_cqt*5)/100);
        v_Nguong_Min := v_Temp/10000;

        IF (v_Nguong_Min > 100000) THEN
            v_Nguong_Min := 100000;
        END IF;

        IF ((ABS(v_Array_Of_Record_Dtl(18).sothue_cqt) < v_Temp - v_Nguong_Min) OR
            (ABS(v_Array_Of_Record_Dtl(18).sothue_cqt) > v_Temp + v_Nguong_Min)) THEN
            v_Array_Of_Record_Dtl(18).ke_khai_sai := 'Y';
            v_Array_Of_Record_Dtl(18).sothue_cqt := v_Temp;
        END IF;

       	--Chi Tieu [32]*10% - Nguong <= |[33]| <= [32]*10% + Nguong
        v_Temp := ROUND((v_Array_Of_Record_Dtl(19).doanhso_cqt*10)/100);
        v_Nguong_Min := v_Temp/10000;
        IF (v_Nguong_Min > 100000) THEN
            v_Nguong_Min := 100000;
        END IF;

        IF ((ABS(v_Array_Of_Record_Dtl(19).sothue_cqt) < v_Temp - v_Nguong_Min) OR
            (ABS(v_Array_Of_Record_Dtl(19).sothue_cqt) > v_Temp + v_Nguong_Min)) THEN
            v_Array_Of_Record_Dtl(19).ke_khai_sai := 'Y';
            v_Array_Of_Record_Dtl(19).sothue_cqt := v_Temp;
        END IF;

        /* Xu ly chi tieu 28 = 31 + 33 */
        v_Array_Of_Record_Dtl(16).sothue_cqt := v_Array_Of_Record_Dtl(18).sothue_cqt +
                                                v_Array_Of_Record_Dtl(19).sothue_cqt;

        /* Xu ly chi tieu 25 = 28*/
        v_Array_Of_Record_Dtl(14).sothue_cqt := v_Array_Of_Record_Dtl(16).sothue_cqt;

        /* Xu ly chi tieu 39 = 25 + 35 - 37 */
        v_Array_Of_Record_Dtl(23).sothue_cqt := v_Array_Of_Record_Dtl(14).sothue_cqt +
                                                 v_Array_Of_Record_Dtl(21).sothue_cqt -
                                                 v_Array_Of_Record_Dtl(22).sothue_cqt;

        /* 39 - 23 - 11 */
        v_Temp := v_Array_Of_Record_Dtl(23).sothue_cqt -
                  v_Array_Of_Record_Dtl(12).sothue_dtnt -
                  v_Array_Of_Record_Dtl(2).sothue_cqt;

        IF (v_Temp > 0) THEN
            --Neu > 0 ghi vao chi tieu [40]
            v_Array_Of_Record_Dtl(25).sothue_cqt := v_Temp;
        ELSIF (v_Temp < 0) THEN
            --Neu < 0 ghi vao chi tieu [41]
            v_Array_Of_Record_Dtl(26).sothue_cqt := ABS(v_Temp);
        ELSE
            v_Array_Of_Record_Dtl(25).sothue_cqt := 0;
            v_Array_Of_Record_Dtl(26).sothue_cqt := 0;
        END IF;

        /*Xu ly chi tieu [43] = [41]-[42], khi khong co chi tieu [40]*/
        IF (v_Array_Of_Record_Dtl(25).sothue_cqt = 0) THEN
            v_Array_Of_Record_Dtl(28).sothue_cqt := v_Array_Of_Record_Dtl(26).sothue_cqt -
                                                    v_Array_Of_Record_Dtl(27).sothue_cqt;
        END IF;

        FOR i IN 1..v_Count LOOP
            IF (i NOT IN (18,19)) THEN
                IF (v_Array_Of_Record_Dtl(i).doanhso_dtnt <>
                    v_Array_Of_Record_Dtl(i).doanhso_cqt
                    OR
                    v_Array_Of_Record_Dtl(i).sothue_dtnt <>
                    v_Array_Of_Record_Dtl(i).sothue_cqt)
                THEN
                    v_Array_Of_Record_Dtl(i).ke_khai_sai := 'Y';
                    v_Sai_SoHoc := 'Y';
                END IF;
            END IF;
        END LOOP;

        /*Tinh toan so thue phat sinh*/
        v_Thue_Dau_Ra := v_Array_Of_Record_Dtl(23).sothue_dtnt; --Chi tieu 39
        v_Thue_Dau_Vao := v_Array_Of_Record_Dtl(12).sothue_dtnt; --Chi tieu 23
        v_Thue_KTru_KySau := v_Array_Of_Record_Dtl(28).sothue_dtnt; --Chi tieu 43;
        v_Thue_PSinh_KyNay := v_Array_Of_Record_Dtl(23).sothue_dtnt -
                              v_Array_Of_Record_Dtl(12).sothue_dtnt; -- = 39-23
        v_Thue_KTru_KyNay := v_Array_Of_Record_Dtl(2).sothue_dtnt +
                             v_Array_Of_Record_Dtl(12).sothue_dtnt -
                             v_Array_Of_Record_Dtl(27).sothue_dtnt -
                             v_Array_Of_Record_Dtl(28).sothue_dtnt; -- = 11+23-42-43
        v_Thue_PNop_KyNay := v_Array_Of_Record_Dtl(25).sothue_dtnt; --Chi tieu 40;
        /*Ket thuc tinh toan so thue phat sinh*/

        /********************************************************/
        /*Ket thuc kiem tra ke khai sai voi cac chi tieu to khai*/

        /*Xu ly to khai*/
        IF (p_TKhai_Exits_Id IS NOT NULL) THEN
            /*Neu da ton tai to khai trong ky ke khai*/
            Qlt_Pck_Gdich.Prc_Lay_Thamso(p_Tthai_Tkhai,p_Record_Of_Header.loai_tkhai);
            Qlt_Pck_Control.Prc_Gan_Tin(p_Record_Of_Header.tin);
            Qlt_Pck_Control.Prc_Reset_Log_Id;
            /*Sinh giao dich*/
            Qlt_Pck_Gdich.Prc_Set_GTGT_2004;

            /*Thuc hien backup to khai, phu luc va cac chung tu lien quan*/
            Qlt_Pck_TKhai.Prc_Backup_TKhai('QLT_TKHAI_HDR','14',p_TKhai_Exits_Id);

            /*Thong tin Header*/
            UPDATE qlt_tkhai_hdr
               SET co_loi = v_Sai_SoHoc,
                   co_loi_ddanh = p_Record_Of_Header.co_loi_ddanh,
                   ghi_chu_loi = p_Record_Of_Header.ghi_chu_loi,
                   co_gtrinh_02a = p_Record_Of_Header.co_gtrinh_02a,
                   co_gtrinh_02b = p_Record_Of_Header.co_gtrinh_02b,
                   co_gtrinh_02c = p_Record_Of_Header.co_gtrinh_02c,
                   so_hieu_tep = p_Record_Of_Header.so_hieu_tep,
                   so_tt_tk = p_Record_Of_Header.so_tt_tk,
                   ngay_nop = p_Record_Of_Header.ngay_nop,
                   kylb_tu_ngay = p_Record_Of_Header.kylb_tu_ngay,
                   kylb_den_ngay = p_Record_Of_Header.kylb_den_ngay,
                   kykk_tu_ngay = p_Record_Of_Header.kykk_tu_ngay,
                   kykk_den_ngay = p_Record_Of_Header.kykk_den_ngay,
                   tthai = '4', --To khai thay the
                   ngay_cap_nhat = p_Record_Of_Header.ngay_cap_nhat,
                   nguoi_cap_nhat = p_Record_Of_Header.nguoi_cap_nhat
            WHERE (id = p_TKhai_Exits_Id)
              AND (ltd = 0);

            /*Thong tin Detail*/
            FOR id IN 1..v_Count LOOP
                v_Index := v_Index + 1;
                UPDATE qlt_tkhai_gtgt_kt
                   SET doanhso_dtnt = v_Array_Of_Record_Dtl(v_Index).doanhso_dtnt,
                       sothue_dtnt = v_Array_Of_Record_Dtl(v_Index).sothue_dtnt,
                       doanhso_cqt = NVL(v_Array_Of_Record_Dtl(v_Index).doanhso_cqt,0),
                       sothue_cqt = NVL(v_Array_Of_Record_Dtl(v_Index).sothue_cqt,0),
                       ke_khai_sai = v_Array_Of_Record_Dtl(v_Index).ke_khai_sai
                WHERE (tkh_id = p_TKhai_Exits_Id)
                  AND (tkh_ltd = 0)
                  AND (ctk_id = v_Array_Of_Record_Dtl(v_Index).ctk_id);
            END LOOP;

            /*Thong tin bang phat sinh*/
            UPDATE qlt_htoan_tkhai_gtgt_kt_2004
               SET thue_psinh_knay = v_Thue_PSinh_KyNay,
                   thue_ktru_knay = v_Thue_KTru_KyNay,
                   thue_pnop_knay = v_Thue_PNop_KyNay,
                   thue_ktru_ksau = v_Thue_KTru_KySau,
                   thue_dau_vao = v_Thue_Dau_Vao,
                   thue_dau_ra = v_Thue_Dau_Ra
            WHERE (tkh_id = p_TKhai_Exits_Id)
              AND (tkh_ltd = 0);

            /*Thong tin phu luc 2A*/
            /*Xoa ban ghi cu neu co*/
            DELETE FROM qlt_gtrinh_gtgt_kt_02a
            WHERE (tkh_id = p_TKhai_Exits_Id)
              AND (tkh_ltd = 0);

            IF (p_Record_Of_Header.co_gtrinh_02a = 'Y') THEN
                /*Insert ban ghi moi*/
                INSERT INTO qlt_gtrinh_gtgt_kt_02a(id,
                                                   tkh_id,
                                                   tkh_ltd,
                                                   ctk_id,
                                                   dien_giai,
                                                   ky_hieu,
                                                   kykk_tu_ngay,
                                                   kykk_den_ngay,
                                                   gia_tri_kkhai,
                                                   gia_tri_dchinh,
                                                   gia_tri_hhdv,
                                                   gia_tri_thue,
                                                   ghi_chu)
                SELECT qlt_dm_ctieu_tkhai_seq.NEXTVAL,
                       p_TKhai_Exits_Id,
                       0,
                       DECODE(pluc2a.ky_hieu,'18',255,'19',255,'20',255,'21',255,
                                             '34',264,'35',264,'36',264,'37',264) ctk_id,
                       pluc2a.dien_giai,
                       pluc2a.ky_hieu,
                       TRUNC(TO_DATE(pluc2a.gia_tri_ky_kkhai,'MM/RRRR'),'MONTH'),
                       LAST_DAY(TRUNC(TO_DATE(pluc2a.gia_tri_ky_kkhai,'MM/RRRR'),'MONTH')),
                       pluc2a.gia_tri_slieu_kkhai,
                       pluc2a.gia_tri_slieu_dchinh,
                       pluc2a.gia_tri_hhdv,
                       pluc2a.gia_tri_thue_gtgt,
                       pluc2a.gia_tri_lydo_dchinh
                FROM rcv_v_tkhai_gtgt_kt_pluc2a pluc2a
                WHERE (pluc2a.hdr_id = p_Record_Of_Header.id)
                  AND (pluc2a.ky_hieu IS NOT NULL);
            END IF;

            /*Xoa ban ghi cu neu co cua phu luc 2B, 2C neu co*/
            DELETE FROM qlt_gtrinh_gtgt_kt_02bc
            WHERE (tkh_id = p_TKhai_Exits_Id)
              AND (tkh_ltd = 0);

            /*Insert ban ghi phu luc 2B moi*/
            INSERT INTO qlt_gtrinh_gtgt_kt_02bc(id,
                                                tkh_id,
                                                tkh_ltd,
                                                ctg_id,
                                                gia_tri_kkhai)
            SELECT qlt_dm_ctieu_tkhai_seq.NEXTVAL,
                   p_TKhai_Exits_Id,
                   0,
                   pluc2b.ctg_id,
                   pluc2b.gia_tri_ctieu
            FROM rcv_v_tkhai_gtgt_kt_pluc2b pluc2b
            WHERE (pluc2b.hdr_id = p_Record_Of_Header.id);

            /*Insert ban ghi phu luc 2C moi*/
            INSERT INTO qlt_gtrinh_gtgt_kt_02bc(id,
                                                tkh_id,
                                                tkh_ltd,
                                                ctg_id,
                                                gia_tri_kkhai)
            SELECT qlt_dm_ctieu_tkhai_seq.NEXTVAL,
                   p_TKhai_Exits_Id,
                   0,
                   pluc2c.ctg_id,
                   pluc2c.gia_tri_ctieu
            FROM rcv_v_tkhai_gtgt_kt_pluc2c pluc2c
            WHERE (pluc2c.hdr_id = p_Record_Of_Header.id);
            /*Ket thuc cap nhat thong tin cho to khai thay the*/
        ELSE
            /*Neu chua ton tai to khai trong ky ke khai*/
            IF (Fnc_AnDinh_Exits(p_Record_Of_Header.tin,
                                 p_Record_Of_Header.loai_tkhai,
                                 p_Record_Of_Header.kykk_tu_ngay,
                                 p_Record_Of_Header.kykk_den_ngay)) THEN /*Neu co an dinh*/
                v_Tthai_Tkhai := '3'; /*To khai nop cham*/
            ELSE /*Neu chua co an dinh*/
                v_HanNop := Fnc_Han_Nop(p_Record_Of_Header.loai_tkhai,
                                        'TK',
                                        p_Record_Of_Header.kykk_den_ngay);
                IF (p_Record_Of_Header.ngay_nop <= v_HanNop) THEN
                    --To khai dung han
                    v_Tthai_Tkhai := '1'; /*To khai chinh thuc*/
                ELSE
                    --To khai khong dung han
                    v_Tthai_Tkhai := '3'; /*To khai nop cham*/
                END IF;
            END IF;

            Qlt_Pck_Gdich.Prc_Lay_Thamso(v_Tthai_Tkhai,p_Record_Of_Header.loai_tkhai);
            Qlt_Pck_Control.Prc_Gan_Tin(p_Record_Of_Header.tin);
            Qlt_Pck_Control.Prc_Reset_Log_Id;
            /*Sinh giao dich*/
            Qlt_Pck_Gdich.Prc_Set_GTGT_2004;

            /*Thuc hien xu ly to khai*/
            SELECT qlt_xltk_hdr_seq.NEXTVAL INTO v_Hdr_Id FROM dual;
            /*Xu ly voi du lieu to khai Header*/
            INSERT INTO qlt_tkhai_hdr(id,
                                      ltd,
                                      tin,
                                      ten_dtnt,
                                      cqt_ma_cqt,
                                      hun_ma_tinh,
                                      hun_ma_huyen,
                                      dia_chi,
                                      ma_phong,
                                      ma_can_bo,
                                      dtk_ma_loai_tkhai,
                                      ngay_nop,
                                      kylb_tu_ngay,
                                      kylb_den_ngay,
                                      kykk_tu_ngay,
                                      kykk_den_ngay,
                                      tthai,
                                      co_loi,
                                      co_loi_ddanh,
                                      ghi_chu_loi,
                                      co_gtrinh_02a,
                                      co_gtrinh_02b,
                                      co_gtrinh_02c,
                                      so_hieu_tep,
                                      so_tt_tk,
                                      ngay_cap_nhat,
                                      nguoi_cap_nhat)
            VALUES(v_Hdr_Id,
                   0,
                   p_Record_Of_Header.tin,
                   p_Record_Of_Header.ten_dtnt,
                   p_Record_Dtnt.ma_cqt,
                   p_Record_Dtnt.ma_tinh,
                   p_Record_Dtnt.ma_huyen,
                   p_Record_Of_Header.dia_chi,
                   p_Record_Dtnt.ma_phong,
                   p_Record_Dtnt.ma_canbo,
                   p_Record_Of_Header.loai_tkhai,
                   p_Record_Of_Header.ngay_nop,
                   p_Record_Of_Header.kylb_tu_ngay,
                   p_Record_Of_Header.kylb_den_ngay,
                   p_Record_Of_Header.kykk_tu_ngay,
                   p_Record_Of_Header.kykk_den_ngay,
                   v_Tthai_Tkhai,
                   v_Sai_SoHoc,
                   p_Record_Of_Header.co_loi_ddanh,
                   p_Record_Of_Header.ghi_chu_loi,
                   p_Record_Of_Header.co_gtrinh_02a,
                   p_Record_Of_Header.co_gtrinh_02b,
                   p_Record_Of_Header.co_gtrinh_02c,
                   p_Record_Of_Header.so_hieu_tep,
                   p_Record_Of_Header.so_tt_tk,
                   p_Record_Of_Header.ngay_cap_nhat,
                   p_Record_Of_Header.nguoi_cap_nhat);

            /*Insert du lieu vao bang to khai Detail*/
            FOR i IN 1..v_Count LOOP
                INSERT INTO qlt_tkhai_gtgt_kt(id,
                                              tkh_id,
                                              tkh_ltd,
                                              ctk_id,
                                              so_tt,
                                              doanhso_dtnt,
                                              sothue_dtnt,
                                              doanhso_cqt,
                                              sothue_cqt,
                                              ke_khai_sai,
                                              ma_so_ct_thue,
                                              ma_so_ct_doanh_so)
                VALUES(v_Array_Of_Record_Dtl(i).id,
                       v_Hdr_Id,
                       0,
                       v_Array_Of_Record_Dtl(i).ctk_id,
                       v_Array_Of_Record_Dtl(i).so_tt,
                       v_Array_Of_Record_Dtl(i).doanhso_dtnt,
                       v_Array_Of_Record_Dtl(i).sothue_dtnt,
                       NVL(v_Array_Of_Record_Dtl(i).doanhso_cqt,0),
                       NVL(v_Array_Of_Record_Dtl(i).sothue_cqt,0),
                       v_Array_Of_Record_Dtl(i).ke_khai_sai,
                       v_Array_Of_Record_Dtl(i).ma_so_ct_thue,
                       v_Array_Of_Record_Dtl(i).ma_so_ct_doanhso);
            END LOOP;

            /*Dua so lieu phat sinh vao bang hach toan*/
            /***************************************************************/
            INSERT INTO qlt_htoan_tkhai_gtgt_kt_2004(id,
                                                     tkh_id,
                                                     tkh_ltd,
                                                     ccg_ma_cap,
                                                     ccg_ma_chuong,
                                                     lkn_ma_loai,
                                                     lkn_ma_khoan,
                                                     tmt_ma_muc,
                                                     tmt_ma_tmuc,
                                                     tmt_ma_thue,
                                                     thue_psinh_knay,
                                                     thue_ktru_knay,
                                                     thue_pnop_knay,
                                                     thue_ktru_ksau,
                                                     thue_dau_vao,
                                                     thue_dau_ra)
             VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                    v_Hdr_Id,
                    0,
                    p_Record_Dtnt.ma_cap,
                    p_Record_Dtnt.ma_chuong,
                    p_Record_Dtnt.ma_loai,
                    p_Record_Dtnt.ma_khoan,
                    '014',
                    '01',
                    '01',
                    v_Thue_PSinh_KyNay,
                    v_Thue_KTru_KyNay,
                    v_Thue_PNop_KyNay,
                    v_Thue_KTru_KySau,
                    v_Thue_Dau_Vao,
                    v_Thue_Dau_Ra);
            /************************************************************************/
            /*Ket thuc dua so lieu phat sinh vao bang hach toan*/

            /*Thuc hien cap nhat du lieu cho cac phu luc giai trinh*/
            /*******************************************************/

            /*Xu ly du lieu ban giai trinh 2A*/
            INSERT INTO qlt_gtrinh_gtgt_kt_02a(id,
                                               tkh_id,
                                               tkh_ltd,
                                               ctk_id,
                                               dien_giai,
                                               ky_hieu,
                                               kykk_tu_ngay,
                                               kykk_den_ngay,
                                               gia_tri_kkhai,
                                               gia_tri_dchinh,
                                               gia_tri_hhdv,
                                               gia_tri_thue,
                                               ghi_chu)
            SELECT qlt_dm_ctieu_tkhai_seq.NEXTVAL,
                   v_Hdr_Id,
                   0,
                   DECODE(pluc2a.ky_hieu,'18',255,'19',255,'20',255,'21',255,
                                         '34',264,'35',264,'36',264,'37',264) ctk_id,
                   pluc2a.dien_giai,
                   pluc2a.ky_hieu,
                   TRUNC(TO_DATE(pluc2a.gia_tri_ky_kkhai,'MM/RRRR'),'MONTH'),
                   LAST_DAY(TRUNC(TO_DATE(pluc2a.gia_tri_ky_kkhai,'MM/RRRR'),'MONTH')),
                   pluc2a.gia_tri_slieu_kkhai,
                   pluc2a.gia_tri_slieu_dchinh,
                   pluc2a.gia_tri_hhdv,
                   pluc2a.gia_tri_thue_gtgt,
                   pluc2a.gia_tri_lydo_dchinh
            FROM rcv_v_tkhai_gtgt_kt_pluc2a pluc2a
            WHERE (pluc2a.hdr_id = p_Record_Of_Header.id)
              AND (pluc2a.ky_hieu IS NOT NULL);
            /*Ket thuc xu ly du lieu ban giai trinh 2A*/

            /*Xu ly du lieu ban giai trinh 2B*/
            INSERT INTO qlt_gtrinh_gtgt_kt_02bc(id,
                                                tkh_id,
                                                tkh_ltd,
                                                ctg_id,
                                                gia_tri_kkhai)
            SELECT qlt_dm_ctieu_tkhai_seq.NEXTVAL,
                   v_Hdr_Id,
                   0,
                   pluc2b.ctg_id,
                   pluc2b.gia_tri_ctieu
            FROM rcv_v_tkhai_gtgt_kt_pluc2b pluc2b
            WHERE (pluc2b.hdr_id = p_Record_Of_Header.id);
            /*Ket thuc xu ly du lieu ban giai trinh 2B*/

            /*Xu ly du lieu ban giai trinh 2C*/
            INSERT INTO qlt_gtrinh_gtgt_kt_02bc(id,
                                                tkh_id,
                                                tkh_ltd,
                                                ctg_id,
                                                gia_tri_kkhai)
            SELECT qlt_dm_ctieu_tkhai_seq.NEXTVAL,
                   v_Hdr_Id,
                   0,
                   pluc2c.ctg_id,
                   pluc2c.gia_tri_ctieu
            FROM rcv_v_tkhai_gtgt_kt_pluc2c pluc2c
            WHERE (pluc2c.hdr_id = p_Record_Of_Header.id);
            /*Ket thuc xu ly du lieu ban giai trinh 2C*/

            /******************************************************/
            /*Ket thuc cap nhat du lieu cho cac phu luc giai trinh*/
        END IF;
        /*Ket thuc xu ly to khai*/
        --Xoa mang trung gian
        v_Array_Of_Record_Dtl.DELETE;

        /*Sau khi dua thanh cong du lieu 1 to khai tu CSDL trung gian sang
         CSDL QLT, thuc hien cap nhat trang thai*/
        UPDATE rcv_tkhai_hdr
        SET da_nhan = 'Y' --Cap nhat da chuyen thanh cong
        WHERE (id = p_Record_Of_Header.id);
    END;
/*******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 12/01/2006
Muc dich: Thuc hien do du lieu to khai TNDN quy vao cac CSDL TKN_TC
Tham so:
        - p_Record_Of_Header: Bien ban ghi chua du lieu cua mot record
                              trong bang RCV_TKHAI_HDR
        - p_Record_Dtnt: Bien ban ghi chua thong tin DTNT
        - p_TKhai_Exits_Id: Id cua to khai da ton tai
        - p_Tthai_Tkhai: Trang thai cua to khai da ton tai
*******************************************************************************/
    PROCEDURE Prc_TKhai_TNDN_Quy(p_Record_Of_Header Record_Hdr,
                                 p_Record_Dtnt Record_Dtnt,
                                 p_TKhai_Exits_Id NUMBER,
                                 p_Tthai_Tkhai VARCHAR2) IS
        CURSOR c_TKhai_TNDN_Quy IS
            SELECT *
            FROM rcv_v_tkhai_tndn_quy tkhai_quy
            WHERE (tkhai_quy.hdr_id = p_Record_Of_Header.id)
            ORDER BY tkhai_quy.so_tt;

        CURSOR c_Ma_Thue IS
            SELECT dm.lte_ma_thue
            FROM qlt_dm_tkhai dm
            WHERE (dm.ma = p_Record_Of_Header.loai_tkhai);

        v_Hdr_Id NUMBER(10);
        v_Ma_Thue VARCHAR2(2);
        v_Thue_PSinh NUMBER(20,2);
        v_Tthai_Tkhai VARCHAR2(1);
        v_HanNop DATE;
        
    BEGIN
        IF (p_TKhai_Exits_Id IS NOT NULL) THEN
        --Neu da ton tai to khai trong ky ke khai
            --Gan tham so sinh giao dich
            Qlt_Pck_Gdich.Prc_Lay_Thamso(p_Tthai_Tkhai, p_Record_Of_Header.loai_tkhai);
            Qlt_Pck_Control.Prc_Gan_Tin(p_Record_Of_Header.tin);
            --Thuc hien backup to khai
            Qlt_Pck_TKhai.Prc_Backup_TKhai('QLT_TKHAI_HDR',
                                           p_Record_Of_Header.loai_tkhai,
                                           p_TKhai_Exits_Id);

                   --Update thong tin Header
            UPDATE qlt_tkhai_hdr
               SET co_loi_ddanh = p_Record_Of_Header.co_loi_ddanh,
                   ghi_chu_loi = p_Record_Of_Header.ghi_chu_loi,
                   so_hieu_tep = p_Record_Of_Header.so_hieu_tep,
                   so_tt_tk = p_Record_Of_Header.so_tt_tk,
                   ngay_nop = p_Record_Of_Header.ngay_nop,
                   kylb_tu_ngay = p_Record_Of_Header.kylb_tu_ngay,
                   kylb_den_ngay = p_Record_Of_Header.kylb_den_ngay,
                   kykk_tu_ngay = p_Record_Of_Header.kykk_tu_ngay,
                   kykk_den_ngay = p_Record_Of_Header.kykk_den_ngay,
                   tthai = '4', --To khai thay the
                   ngay_cap_nhat = p_Record_Of_Header.ngay_cap_nhat,
                   nguoi_cap_nhat = p_Record_Of_Header.nguoi_cap_nhat
            WHERE (id = p_TKhai_Exits_Id)
              AND (ltd = 0);

            --Update du lieu to khai TNDN quy
            FOR vc_TKhai_TNDN_Quy IN c_TKhai_TNDN_Quy LOOP
                UPDATE qlt_tkhai_tndn_quy
                SET so_dtnt = NVL(vc_TKhai_TNDN_Quy.so_dtnt,0),
                    so_cqt = NVL(vc_TKhai_TNDN_Quy.so_dtnt,0)
                WHERE (tkh_id = p_TKhai_Exits_Id)
                  AND (tkh_ltd = 0)
                  AND (so_tt = vc_TKhai_TNDN_Quy.so_tt);

                --Update so thue phat sinh trong bang phat sinh
                IF (vc_TKhai_TNDN_Quy.so_tt = 9) THEN
                    UPDATE qlt_psinh_tkhai
                    SET thue_psinh = NVL(vc_TKhai_TNDN_Quy.so_dtnt,0)
                    WHERE (tkh_id = p_TKhai_Exits_Id)
                      AND (tkh_ltd = 0);
                END IF;
            END LOOP;
        ELSE
            --Neu chua ton tai to khai trong ky ke khai
            IF (Fnc_AnDinh_Exits(p_Record_Of_Header.tin,
                                 p_Record_Of_Header.loai_tkhai,
                                 p_Record_Of_Header.kykk_tu_ngay,
                                 p_Record_Of_Header.kykk_den_ngay)) THEN /*Neu co an dinh*/
                v_Tthai_Tkhai := '3'; /*To khai nop cham*/
            ELSE /*Neu chua co an dinh*/
                v_HanNop := Fnc_Han_Nop(p_Record_Of_Header.loai_tkhai,
                                        'TK',
                                        p_Record_Of_Header.kykk_den_ngay,
                                        p_Record_Dtnt.ngay_tchinh);
                IF (p_Record_Of_Header.ngay_nop <= v_HanNop) THEN
                    --To khai dung han
                    v_Tthai_Tkhai := '1'; /*To khai chinh thuc*/
                ELSE
                    --To khai khong dung han
                    v_Tthai_Tkhai := '3'; /*To khai nop cham*/
                END IF;
            END IF;
            
            --Gan tham so sinh giao dich
            Qlt_Pck_Gdich.Prc_Lay_Thamso(v_Tthai_Tkhai, p_Record_Of_Header.loai_tkhai);
            Qlt_Pck_Control.Prc_Gan_Tin(p_Record_Of_Header.tin);

            SELECT qlt_xltk_hdr_seq.NEXTVAL INTO v_Hdr_Id FROM dual;
            --Xu ly du lieu to khai Header
            INSERT INTO qlt_tkhai_hdr(id,
                                      ltd,
                                      tin,
                                      ten_dtnt,
                                      cqt_ma_cqt,
                                      hun_ma_tinh,
                                      hun_ma_huyen,
                                      dia_chi,
                                      ma_phong,
                                      ma_can_bo,
                                      dtk_ma_loai_tkhai,
                                      ngay_nop,
                                      kylb_tu_ngay,
                                      kylb_den_ngay,
                                      kykk_tu_ngay,
                                      kykk_den_ngay,
                                      tthai,
                                      co_loi_ddanh,
                                      ghi_chu_loi,
                                      so_hieu_tep,
                                      so_tt_tk,
                                      ngay_cap_nhat,
                                      nguoi_cap_nhat)
            VALUES(v_Hdr_Id,
                   0,
                   p_Record_Of_Header.tin,
                   p_Record_Of_Header.ten_dtnt,
                   p_Record_Dtnt.ma_cqt,
                   p_Record_Dtnt.ma_tinh,
                   p_Record_Dtnt.ma_huyen,
                   p_Record_Of_Header.dia_chi,
                   p_Record_Dtnt.ma_phong,
                   p_Record_Dtnt.ma_canbo,
                   p_Record_Of_Header.loai_tkhai,
                   p_Record_Of_Header.ngay_nop,
                   p_Record_Of_Header.kylb_tu_ngay,
                   p_Record_Of_Header.kylb_den_ngay,
                   p_Record_Of_Header.kykk_tu_ngay,
                   p_Record_Of_Header.kykk_den_ngay,
                   v_Tthai_Tkhai,
                   p_Record_Of_Header.co_loi_ddanh,
                   p_Record_Of_Header.ghi_chu_loi,
                   p_Record_Of_Header.so_hieu_tep,
                   p_Record_Of_Header.so_tt_tk,
                   p_Record_Of_Header.ngay_cap_nhat,
                   p_Record_Of_Header.nguoi_cap_nhat);

            --Xu ly du lieu to khai Detail
            FOR vc_TKhai_TNDN_Quy IN c_TKhai_TNDN_Quy LOOP
                INSERT INTO qlt_tkhai_tndn_quy (id,
                                                tkh_id,
                                                tkh_ltd,
                                                ctk_id,
                                                so_tt,
                                                so_dtnt,
                                                so_cqt,
                                                ke_khai_sai)
                VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                        v_Hdr_Id,
                        0,
                        vc_TKhai_TNDN_Quy.ctk_id,
                        NVL(vc_TKhai_TNDN_Quy.so_tt,0),
                        NVL(vc_TKhai_TNDN_Quy.so_dtnt,0),
                        NVL(vc_TKhai_TNDN_Quy.so_dtnt,0),
                        null);
                --Luu so thue phat sinh
                IF (vc_TKhai_TNDN_Quy.so_tt = 9) THEN
                    v_Thue_PSinh := NVL(vc_TKhai_TNDN_Quy.so_dtnt,0);
                END IF;
            END LOOP;

            OPEN c_Ma_Thue;
            FETCH c_Ma_Thue INTO v_Ma_Thue;
            CLOSE c_Ma_Thue;

            --Xu ly du lieu voi bang phat sinh
            INSERT INTO qlt_psinh_tkhai (id,
                                         tkh_id,
                                         tkh_ltd,
                                         ccg_ma_cap,
                                         ccg_ma_chuong,
                                         lkn_ma_loai,
                                         lkn_ma_khoan,
                                         tmt_ma_muc,
                                         tmt_ma_tmuc,
                                         tmt_ma_thue,
                                         thue_psinh,
                                         can_cu_tt)
            VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                    v_Hdr_Id,
                    0,
                    p_Record_Dtnt.ma_cap,
                    p_Record_Dtnt.ma_chuong,
                    p_Record_Dtnt.ma_loai,
                    p_Record_Dtnt.ma_khoan,
                    '002',
                    '02',
                    v_Ma_Thue,
                    v_Thue_PSinh,
                    0);
        END IF;

        /*Sau khi dua thanh cong du lieu 1 to khai tu CSDL trung gian sang
         CSDL QLT, thuc hien cap nhat trang thai*/
        UPDATE rcv_tkhai_hdr
        SET da_nhan = 'Y' --Cap nhat da chuyen thanh cong
        WHERE (id = p_Record_Of_Header.id);
    END;
/*******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 19/01/2006
Muc dich: Thuc hien do du lieu to khai quyet toan TNDN nam vao cac bang
          trong CSDL TKN_TC
Tham so:
        - p_Record_Of_Header: Bien ban ghi chua du lieu cua mot record
                              trong bang RCV_TKHAI_HDR
        - p_Record_Dtnt: Bien ban ghi chua thong tin DTNT
        - p_TKhai_Exits_Id: Id cua to khai da ton tai
        - p_Tthai_Tkhai: Trang thai cua to khai da ton tai
*******************************************************************************/
    PROCEDURE Prc_TKhai_QToan_TNDN_Nam(p_Record_Of_Header Record_Hdr,
                                       p_Record_Dtnt Record_Dtnt,
                                       p_TKhai_Exits_Id NUMBER,
                                       p_Tthai_Tkhai VARCHAR2) IS
        --Lay so lieu to khai quyet toan
        CURSOR c_TKhai_QToan_TNDN_Nam IS
            SELECT *
            FROM rcv_v_tkhai_qtoan_tndn qtoan
            WHERE (qtoan.hdr_id = p_Record_Of_Header.id)
            ORDER BY qtoan.ky_hieu_ctieu, qtoan.so_tt;
        vc_TKhai_QToan_TNDN_Nam c_TKhai_QToan_TNDN_Nam%ROWTYPE;

        --Lay ma thue
        CURSOR c_Ma_Thue IS
        	SELECT lte_ma_thue
        	FROM qlt_dm_qtoan
        	WHERE (ma = p_Record_Of_Header.loai_tkhai);

        --Lay cac nam chuyen lo
        CURSOR c_Nam_ChuyenLo(p_Loai_PLuc VARCHAR2) IS
            SELECT pluc_01AB.lo_chuyen_01 nam_chuyen_1,
                   pluc_01AB.lo_chuyen_02 nam_chuyen_2,
                   pluc_01AB.lo_chuyen_03 nam_chuyen_3,
                   pluc_01AB.lo_chuyen_04 nam_chuyen_4,
                   pluc_01AB.lo_chuyen_05 nam_chuyen_5,
                   pluc_01AB.lo_chuyen_06 nam_chuyen_6
            FROM rcv_v_pluc_qtoan_tndn_01AB pluc_01AB
            WHERE (pluc_01AB.hdr_id = p_Record_Of_Header.id)
              AND (pluc_01AB.loai_dlieu = p_Loai_PLuc)
              AND (pluc_01AB.nam_psinh IS NULL);
        vc_Nam_ChuyenLo c_Nam_ChuyenLo%ROWTYPE;

        --Lay du lieu phu luc 01A
        CURSOR c_PLuc_01A IS
            SELECT *
            FROM rcv_v_pluc_qtoan_tndn_01AB
            WHERE (hdr_id = p_Record_Of_Header.id)
              AND (loai_dlieu = '0302')
              AND (nam_psinh IS NOT NULL)
            ORDER BY loai_dlieu, so_tt;

        --Lay du lieu phu luc 01B
        CURSOR c_PLuc_01B IS
            SELECT *
            FROM rcv_v_pluc_qtoan_tndn_01AB
            WHERE (hdr_id = p_Record_Of_Header.id)
              AND (loai_dlieu = '0316')
              AND (nam_psinh IS NOT NULL)
            ORDER BY loai_dlieu, so_tt;

        --Lay du lieu tu phu luc 02 den phu luc 13
        CURSOR c_PLuc_02_13 IS
            SELECT *
            FROM rcv_v_pluc_qtoan_tndn_02_13
            WHERE (hdr_id = p_Record_Of_Header.id)
            ORDER BY loai_dlieu, row_id, ky_hieu;
        vc_PLuc_02_13 c_PLuc_02_13%ROWTYPE;

        --Lay du lieu phu luc 14
        CURSOR c_PLuc_14 IS
            SELECT *
            FROM rcv_v_pluc_qtoan_tndn_14
            WHERE (hdr_id = p_Record_Of_Header.id);
        vc_PLuc_14 c_PLuc_14%ROWTYPE;

        v_Tthai_Tkhai VARCHAR2(1);
        v_Hdr_Id NUMBER(10);
        v_PLuc01A_Id NUMBER(10);
        v_PLuc01B_Id NUMBER(10);
        v_Ma_Thue VARCHAR2(2);
        v_So_KKhai_QToan NUMBER(20,2) := 0;
        v_So_KKhai_TKhai NUMBER(20,2) := 0;
        v_So_Clech NUMBER(20,2) := 0;
        v_Count NUMBER(10) := 0;
        v_HanNop DATE;
        
    BEGIN
        --Xu ly so thue phat sinh
        OPEN c_Ma_Thue;
        FETCH c_Ma_Thue INTO v_Ma_Thue;
        CLOSE c_Ma_Thue;
        --Lay so ke khai cua doi tuong trong 12 thang
        v_So_KKhai_TKhai := Fnc_So_KKhai_TKhai (p_Record_Of_Header.tin,
        									    '002',
        									    '02',
        									    v_Ma_Thue,
        									    p_Record_Of_Header.kykk_tu_ngay);

        IF (p_TKhai_Exits_Id IS NOT NULL) THEN
            --Neu da ton tai to khai trong ky ke khai
            v_Hdr_Id := p_TKhai_Exits_Id;
            --Gan tham so sinh giao dich
        	Qlt_Pck_Gdich.Prc_Lay_Thamso_Qtoan(p_Record_Of_Header.loai_tkhai);
        	Qlt_Pck_Control.Prc_Gan_Tin(p_Record_Of_Header.tin);
        	--Thuc hien backup to khai
   		    Qlt_Pck_Tkhai.Prc_Backup_TKhai('QLT_QTOAN_HDR',
                                           p_Record_Of_Header.loai_tkhai,
                                           v_Hdr_Id);
            --Cap nhat thong tin Header
            UPDATE qlt_qtoan_hdr
            SET ngay_nop = p_Record_Of_Header.ngay_nop,
                kylb_tu_ngay = p_Record_Of_Header.kylb_tu_ngay,
                kylb_den_ngay = p_Record_Of_Header.kylb_den_ngay,
                kykk_tu_ngay = p_Record_Of_Header.kykk_tu_ngay,
                kykk_den_ngay = p_Record_Of_Header.kykk_den_ngay,
                tthai = '4', --To khai thay the
                loi_ddanh = p_Record_Of_Header.co_loi_ddanh,
                ghi_chu_loi = p_Record_Of_Header.ghi_chu_loi,
                nguoi_cap_nhat = p_Record_Of_Header.nguoi_cap_nhat,
                so_hieu_tep = p_Record_Of_Header.so_hieu_tep,
                so_tt_tk = p_Record_Of_Header.so_tt_tk
            WHERE (id = v_Hdr_Id)
              AND (ltd = 0);

            --Bo cac tai lieu di kem to khai quyet toan
            UPDATE qlt_pluc_tlieu_qtoan_tndn
            SET co_khong = NULL
            WHERE (quh_id = v_Hdr_Id)
              AND (quh_ltd = 0);

            --Cap nhat thong tin Detail
            FOR vc_TKhai_QToan_TNDN_Nam IN c_TKhai_QToan_TNDN_Nam LOOP
                IF (vc_TKhai_QToan_TNDN_Nam.ky_hieu_ctieu = 'A') THEN
                    --Du lieu Detail quyet toan
                    UPDATE qlt_qtoan_dtl
                    SET so_dtnt = TO_NUMBER(NVL(vc_TKhai_QToan_TNDN_Nam.so_dtnt,0)),
                        so_cqt = TO_NUMBER(NVL(vc_TKhai_QToan_TNDN_Nam.so_dtnt,0))
                    WHERE (quh_id = v_Hdr_Id)
                      AND (quh_ltd = 0)
                      AND (ctq_id = vc_TKhai_QToan_TNDN_Nam.ctq_id);

                    IF (vc_TKhai_QToan_TNDN_Nam.ctq_id = 148) THEN
                        v_So_KKhai_QToan := TO_NUMBER(NVL(vc_TKhai_QToan_TNDN_Nam.so_dtnt,0));
                    END IF;
                ELSE
                    --Cap nhat lai cac tai lieu di kem to khai quyet toan
                    UPDATE qlt_pluc_tlieu_qtoan_tndn
                    SET co_khong = DECODE(vc_TKhai_QToan_TNDN_Nam.so_dtnt,'x','Y',NULL)
                    WHERE (quh_id = v_Hdr_Id)
                      AND (quh_ltd = 0)
                      AND (dmtl_id = vc_TKhai_QToan_TNDN_Nam.ctq_id);
                END IF;
            END LOOP;

            --Tinh so chenh lech quyet toan
            v_So_Clech := v_So_KKhai_QToan - v_So_KKhai_TKhai;

            UPDATE qlt_psinh_qtoan
            SET so_kkhai_qtoan = v_So_KKhai_QToan,
                so_kkhai_tkhai = v_So_KKhai_TKhai,
                so_clech = v_So_Clech
            WHERE (quh_id = v_Hdr_Id)
              AND (quh_ltd = 0);

            --Xoa cac phu luc di kem to khai quyet toan
            --Xoa phu luc 01a, 01b
            DELETE FROM qlt_pluc_qtoan_tndn_01a
            WHERE (quh_id = v_Hdr_Id)
              AND (quh_ltd = 0);

            DELETE FROM qlt_pluc_qtoan_tndn_01b
            WHERE (quh_id = v_Hdr_Id)
              AND (quh_ltd = 0);

            --Xoa cac phu luc tu 2 den 13
            DELETE FROM qlt_pluc_qtoan_tndn_a
            WHERE (quh_id = v_Hdr_Id)
              AND (quh_ltd = 0);

            DELETE FROM qlt_pluc_qtoan_tndn_b
            WHERE (quh_id = v_Hdr_Id)
              AND (quh_ltd = 0);

            --Xoa phu luc 14
            DELETE FROM qlt_pluc_qtoan_tndn_14
            WHERE (quh_id = v_Hdr_Id)
              AND (quh_ltd = 0);
        ELSE
            v_HanNop := Fnc_Han_Nop(p_Record_Of_Header.loai_tkhai,
                                    'QT',
                                    p_Record_Of_Header.kykk_den_ngay,
                                    p_Record_Dtnt.ngay_tchinh);
            IF (p_Record_Of_Header.ngay_nop <= v_HanNop) THEN
                --To khai dung han
                v_Tthai_Tkhai := '1'; /*To khai chinh thuc*/
            ELSE
                --To khai khong dung han
                v_Tthai_Tkhai := '3'; /*To khai nop cham*/
            END IF;
            
            --Neu chua ton tai to khai trong ky ke khai
        	SELECT qlt_xltk_hdr_seq.NEXTVAL INTO v_Hdr_Id FROM dual;
            --Gan tham so sinh giao dich
        	Qlt_Pck_Gdich.Prc_Lay_Thamso_Qtoan(p_Record_Of_Header.loai_tkhai);
        	Qlt_Pck_Control.Prc_Gan_Tin(p_Record_Of_Header.tin);

        	--Thong tin Header quyet toan
            INSERT INTO qlt_qtoan_hdr(id,
                                      ltd,
                                      tin,
                                      ten_dtnt,
                                      cqt_ma_cqt,
                                      hun_ma_huyen,
                                      hun_ma_tinh,
                                      ma_phong,
                                      ma_can_bo,
                                      dia_chi,
                                      nganh_kdoanh,
                                      dien_thoai,
                                      fax,
                                      email,
                                      dqt_ma,
                                      ngay_nop,
                                      kylb_tu_ngay,
                                      kylb_den_ngay,
                                      kykk_tu_ngay,
                                      kykk_den_ngay,
                                      tthai,
                                      loi_so_hoc,
                                      loi_ddanh,
                                      ghi_chu_loi,
                                      nguoi_cap_nhat,
                                      so_hieu_tep,
                                      so_tt_tk)
            VALUES (v_Hdr_Id,
                    0,
                    p_Record_Of_Header.tin,
                    p_Record_Of_Header.ten_dtnt,
                    p_Record_Dtnt.ma_cqt,
                    p_Record_Dtnt.ma_huyen,
                    p_Record_Dtnt.ma_tinh,
                    p_Record_Dtnt.ma_phong,
                    p_Record_Dtnt.ma_canbo,
                    p_Record_Of_Header.dia_chi,
                    NULL,
                    p_Record_Dtnt.dien_thoai,
                    p_Record_Dtnt.fax,
                    p_Record_Dtnt.email,
                    p_Record_Of_Header.loai_tkhai,
                    p_Record_Of_Header.ngay_nop,
                    p_Record_Of_Header.kylb_tu_ngay,
                    p_Record_Of_Header.kylb_den_ngay,
                    p_Record_Of_Header.kykk_tu_ngay,
                    p_Record_Of_Header.kykk_den_ngay,
                    v_Tthai_Tkhai, --Trang thai to khai
                    NULL,
                    p_Record_Of_Header.co_loi_ddanh,
                    p_Record_Of_Header.ghi_chu_loi,
                    p_Record_Of_Header.nguoi_cap_nhat,
                    p_Record_Of_Header.so_hieu_tep,
                    p_Record_Of_Header.so_tt_tk);

            FOR vc_TKhai_QToan_TNDN_Nam IN c_TKhai_QToan_TNDN_Nam LOOP
                IF (vc_TKhai_QToan_TNDN_Nam.ky_hieu_ctieu = 'A') THEN
                    --Du lieu Detail quyet toan
                    INSERT INTO qlt_qtoan_dtl (id,
                                               quh_id,
                                               quh_ltd,
                                               ctq_id,
                                               so_tt,
                                               so_dtnt,
                                               so_cqt,
                                               ke_khai_sai)
                    VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                            v_Hdr_Id,
                            0,
                            vc_TKhai_QToan_TNDN_Nam.ctq_id,
                            vc_TKhai_QToan_TNDN_Nam.so_tt,
                            TO_NUMBER(NVL(vc_TKhai_QToan_TNDN_Nam.so_dtnt,0)),
                            TO_NUMBER(NVL(vc_TKhai_QToan_TNDN_Nam.so_dtnt,0)),
                            NULL);

                    IF (vc_TKhai_QToan_TNDN_Nam.ctq_id = 148) THEN
                        v_so_kkhai_qtoan := TO_NUMBER(NVL(vc_TKhai_QToan_TNDN_Nam.so_dtnt,0));
                    END IF;
                ELSE
                    --Tai lieu di kem to khai quyet toan
                    INSERT INTO qlt_pluc_tlieu_qtoan_tndn(id,
                                                          quh_id,
                                                          quh_ltd,
                                                          dmtl_id,
                                                          so_tt,
                                                          co_khong)
                    VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                            v_Hdr_Id,
                            0,
                            vc_TKhai_QToan_TNDN_Nam.ctq_id,
                            vc_TKhai_QToan_TNDN_Nam.so_tt,
                            DECODE(vc_TKhai_QToan_TNDN_Nam.so_dtnt,'x','Y',NULL));
                END IF;
            END LOOP;

            --Tinh toan so chenh lech
            v_So_Clech := v_So_KKhai_QToan - v_So_KKhai_TKhai;
            --Dua du lieu vao bang phat sinh
            INSERT INTO qlt_psinh_qtoan (id,
                                         quh_id,
                                         quh_ltd,
                                         ccg_ma_cap,
                                         ccg_ma_chuong,
                                         lkn_ma_loai,
                                         lkn_ma_khoan,
                                         tmt_ma_muc,
                                         tmt_ma_tmuc,
                                         tmt_ma_thue,
                                         so_kkhai_qtoan,
                                         so_kkhai_tkhai,
                                         so_clech)
            VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                    v_Hdr_Id,
                    0,
                    p_Record_Dtnt.ma_cap,
                    p_Record_Dtnt.ma_chuong,
                    p_Record_Dtnt.ma_loai,
                    p_Record_Dtnt.ma_khoan,
                    '002',
                    '02',
                    v_Ma_Thue,
                    v_So_KKhai_QToan,
                    v_So_KKhai_TKhai,
                    v_So_Clech);
        END IF;

        ---Xu ly cac phu luc di kem to khai quyet toan---
        
        --Xu ly du lieu phu luc 01A
        OPEN c_Nam_ChuyenLo('0302');
        FETCH c_Nam_ChuyenLo INTO vc_Nam_ChuyenLo;
        CLOSE c_Nam_ChuyenLo;
        
        FOR vc_PLuc_01A IN c_PLuc_01A LOOP
            IF (vc_PLuc_01A.so_tt < 8 AND vc_PLuc_01A.so_tt > 1) THEN
                IF ((vc_PLuc_01A.so_psinh <> 0) OR ((vc_PLuc_01A.so_psinh = 0) AND(vc_PLuc_01A.lo_chuyen_01 <> 0 OR
                                                                                   vc_PLuc_01A.lo_chuyen_02 <> 0 OR
                                                                                   vc_PLuc_01A.lo_chuyen_03 <> 0 OR
                                                                                   vc_PLuc_01A.lo_chuyen_04 <> 0 OR
                                                                                   vc_PLuc_01A.lo_chuyen_05 <> 0 OR
                                                                                   vc_PLuc_01A.lo_chuyen_06 <> 0))) THEN
                    SELECT qlt_xltk_dtl_seq.NEXTVAL INTO v_PLuc01A_Id FROM dual;
                    INSERT INTO qlt_pluc_qtoan_tndn_01a (id,
                                                         quh_id,
                                                         quh_ltd,
                                                         nam_psinh,
                                                         lo_psinh,
                                                         loai)
                    VALUES (v_PLuc01A_Id,
                            v_Hdr_Id,
                            0,
                            TO_DATE(vc_PLuc_01A.nam_psinh,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01A.so_psinh,0)),
                            '01');
                END IF;

                IF (vc_PLuc_01A.lo_chuyen_01 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01A_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_1,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01A.lo_chuyen_01,0)));
                END IF;

                IF (vc_PLuc_01A.lo_chuyen_02 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01A_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_2,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01A.lo_chuyen_02,0)));
                END IF;

                IF (vc_PLuc_01A.lo_chuyen_03 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01A_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_3,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01A.lo_chuyen_03,0)));
                END IF;

                IF (vc_PLuc_01A.lo_chuyen_04 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01A_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_4,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01A.lo_chuyen_04,0)));
                END IF;

                IF (vc_PLuc_01A.lo_chuyen_05 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01A_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_5,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01A.lo_chuyen_05,0)));
                END IF;

                IF (vc_PLuc_01A.lo_chuyen_06 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01A_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_6,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01A.lo_chuyen_06,0)));
                END IF;
            ELSE
                INSERT INTO qlt_pluc_qtoan_tndn_01b (id,
                                                     quh_id,
                                                     quh_ltd,
                                                     nam_psinh,
                                                     lo_psinh,
                                                     lo_chuyen_truoc,
                                                     lo_chuyen_tky,
                                                     lo_chuyen_sau,
                                                     loai)
                VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                        v_Hdr_Id,
                        0,
                        TO_DATE(vc_PLuc_01A.nam_psinh,'RRRR'),
                        TO_NUMBER(NVL(vc_PLuc_01A.so_psinh,0)),
                        TO_NUMBER(NVL(vc_PLuc_01A.lo_chuyen_01,0)),
                        TO_NUMBER(NVL(vc_PLuc_01A.lo_chuyen_02,0)),
                        TO_NUMBER(NVL(vc_PLuc_01A.lo_chuyen_03,0)),
                        '01');
            END IF;
        END LOOP;

        --Xu ly du lieu phu luc 01B
        OPEN c_Nam_ChuyenLo('0316');
        FETCH c_Nam_ChuyenLo INTO vc_Nam_ChuyenLo;
        CLOSE c_Nam_ChuyenLo;
        
        FOR vc_PLuc_01B IN c_PLuc_01B LOOP
            IF (vc_PLuc_01B.so_tt < 8 AND vc_PLuc_01B.so_tt > 1) THEN
                IF ((vc_PLuc_01B.so_psinh <> 0) OR ((vc_PLuc_01B.so_psinh = 0) AND(vc_PLuc_01B.lo_chuyen_01 <> 0 OR
                                                                                   vc_PLuc_01B.lo_chuyen_02 <> 0 OR
                                                                                   vc_PLuc_01B.lo_chuyen_03 <> 0 OR
                                                                                   vc_PLuc_01B.lo_chuyen_04 <> 0 OR
                                                                                   vc_PLuc_01B.lo_chuyen_05 <> 0 OR
                                                                                   vc_PLuc_01B.lo_chuyen_06 <> 0))) THEN
                    SELECT qlt_xltk_dtl_seq.NEXTVAL INTO v_PLuc01B_Id FROM dual;
                    INSERT INTO qlt_pluc_qtoan_tndn_01a (id,
                                                         quh_id,
                                                         quh_ltd,
                                                         nam_psinh,
                                                         lo_psinh,
                                                         loai)
                    VALUES (v_PLuc01B_Id,
                            v_Hdr_Id,
                            0,
                            TO_DATE(vc_PLuc_01B.nam_psinh,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01B.so_psinh,0)),
                            '02');
                END IF;

                IF (vc_PLuc_01B.lo_chuyen_01 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01B_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_1,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01B.lo_chuyen_01,0)));
                END IF;

                IF (vc_PLuc_01B.lo_chuyen_02 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01B_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_2,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01B.lo_chuyen_02,0)));
                END IF;

                IF (vc_PLuc_01B.lo_chuyen_03 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01B_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_3,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01B.lo_chuyen_03,0)));
                END IF;

                IF (vc_PLuc_01B.lo_chuyen_04 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01B_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_4,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01B.lo_chuyen_04,0)));
                END IF;

                IF (vc_PLuc_01B.lo_chuyen_05 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01B_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_5,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01B.lo_chuyen_05,0)));
                END IF;

                IF (vc_PLuc_01B.lo_chuyen_06 <> 0) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_01ad (pdn1a_id,
                                                          nam_chuyen_lo,
                                                          lo_chuyen)
                    VALUES (v_PLuc01B_Id,
                            TO_DATE(vc_Nam_ChuyenLo.nam_chuyen_6,'RRRR'),
                            TO_NUMBER(NVL(vc_PLuc_01B.lo_chuyen_06,0)));
                END IF;
            ELSE
                INSERT INTO qlt_pluc_qtoan_tndn_01b (id,
                                                     quh_id,
                                                     quh_ltd,
                                                     nam_psinh,
                                                     lo_psinh,
                                                     lo_chuyen_truoc,
                                                     lo_chuyen_tky,
                                                     lo_chuyen_sau,
                                                     loai)
                VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                        v_Hdr_Id,
                        0,
                        TO_DATE(vc_PLuc_01B.nam_psinh,'RRRR'),
                        TO_NUMBER(NVL(vc_PLuc_01B.so_psinh,0)),
                        TO_NUMBER(NVL(vc_PLuc_01B.lo_chuyen_01,0)),
                        TO_NUMBER(NVL(vc_PLuc_01B.lo_chuyen_02,0)),
                        TO_NUMBER(NVL(vc_PLuc_01B.lo_chuyen_03,0)),
                        '02');
            END IF;
        END LOOP;

        --Xu ly du lieu phu luc tu 02 - 13
        FOR vc_PLuc_02_13 IN c_PLuc_02_13 LOOP
            IF (vc_PLuc_02_13.ky_hieu = 'A') THEN
                IF (vc_PLuc_02_13.so_dtnt IS NOT NULL) THEN
                    INSERT INTO qlt_pluc_qtoan_tndn_a(id,
                                                      quh_id,
                                                      quh_ltd,
                                                      dcp_id,
                                                      gia_tri,
                                                      kieu_dlieu,
                                                      so_tt)
                    VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                            v_Hdr_Id,
                            0,
                            vc_PLuc_02_13.dcp_id,
                            DECODE(vc_PLuc_02_13.kieu_dlieu,
                                   'D',DECODE(LENGTH(vc_PLuc_02_13.so_dtnt),4,'01/01/'||vc_PLuc_02_13.so_dtnt
                                                                           ,7,'01/'||vc_PLuc_02_13.so_dtnt
                                                                           ,vc_PLuc_02_13.so_dtnt),
                                   'C',DECODE(vc_PLuc_02_13.so_dtnt,'x','Y',vc_PLuc_02_13.so_dtnt),
                                   vc_PLuc_02_13.so_dtnt),
                            vc_PLuc_02_13.kieu_dlieu,
                            vc_PLuc_02_13.row_id);
                END IF;
            ELSE
                INSERT INTO qlt_pluc_qtoan_tndn_b(id,
                                                  quh_id,
                                                  quh_ltd,
                                                  dcp_id,
                                                  so_tt,
                                                  so_dtnt,
                                                  so_cqt,
                                                  ke_khai_sai,
                                                  stt_pluc)
                VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                        v_Hdr_Id,
                        0,
                        vc_PLuc_02_13.dcp_id,
                        vc_PLuc_02_13.so_tt,
                        TO_NUMBER(NVL(vc_PLuc_02_13.so_dtnt,0)),
                        TO_NUMBER(NVL(vc_PLuc_02_13.so_dtnt,0)),
                        NULL,
                        vc_PLuc_02_13.row_id);
            END IF;
        END LOOP;

        --Xu ly phu luc 14
        FOR vc_PLuc_14 IN c_PLuc_14 LOOP
            INSERT INTO qlt_pluc_qtoan_tndn_14 (id,
                                                quh_id,
                                                quh_ltd,
                                                ten_dia_chi,
                                                tnhap_nte,
                                                tnhap_vnd,
                                                thue_nte,
                                                thue_vnd,
                                                tnhap_tndn_nte,
                                                tnhap_tndn_vnd,
                                                tsuat_tndn,
                                                thue_tndn,
                                                thue_ktru)
            VALUES (qlt_xltk_dtl_seq.NEXTVAL,
                    v_Hdr_Id,
                    0,
                    vc_PLuc_14.ten_dia_chi,
                    TO_NUMBER(NVL(vc_PLuc_14.tnhap_nte,0)),
                    TO_NUMBER(NVL(vc_PLuc_14.tnhap_vnd,0)),
                    TO_NUMBER(NVL(vc_PLuc_14.thue_nte,0)),
                    TO_NUMBER(NVL(vc_PLuc_14.thue_vnd,0)),
                    TO_NUMBER(NVL(vc_PLuc_14.tnhap_tndn_nte,0)),
                    TO_NUMBER(NVL(vc_PLuc_14.tnhap_tndn_vnd,0)),
                    TO_NUMBER(NVL(vc_PLuc_14.tsuat_tndn,0)),
                    TO_NUMBER(NVL(vc_PLuc_14.thue_tndn,0)),
                    TO_NUMBER(NVL(vc_PLuc_14.thue_ktru,0)));
        END LOOP;

        /*Sau khi dua thanh cong du lieu 1 to khai tu CSDL trung gian sang
         CSDL QLT, thuc hien cap nhat trang thai*/
        UPDATE rcv_tkhai_hdr
        SET da_nhan = 'Y' --Cap nhat da chuyen thanh cong
        WHERE (id = p_Record_Of_Header.id);
    END;
/*******************************************************************************
Nguoi lap: Nguyen Ta Anh
Ngay lap: 16/11/2005
Muc dich: Thuc hien do du lieu to khai tu CSDL trung gian vao CSDL TKN_TC
Tham so: NONE
*******************************************************************************/
    PROCEDURE Prc_Chuyen_Dlieu_Qlt IS
        /*Lay tat ca cac to khai hien co trong CSDL trung gian, chua duoc chuyen
         vao CSDL QLT (truong "da_nhan" co gia tri NULL)*/
        CURSOR c_Insert_Header_TKhai IS
            SELECT hdr.id,
                   hdr.tin,
                   hdr.ten_dtnt,
                   hdr.dia_chi,
                   tkhai.ma_tkhai_qlt loai_tkhai,
                   tkhai.loai,
                   hdr.ngay_nop,
                   hdr.kylb_tu_ngay,
                   hdr.kylb_den_ngay,
                   hdr.kykk_tu_ngay,
                   hdr.kykk_den_ngay,
                   hdr.ngay_cap_nhat,
                   hdr.nguoi_cap_nhat,
                   DECODE(hdr.co_loi_ddanh,'x','Y',NULL) co_loi_ddanh,
                   hdr.so_hieu_tep,
                   hdr.so_tt_tk,
                   hdr.ghi_chu_loi,
                   hdr.co_gtrinh_02a,
                   hdr.co_gtrinh_02b,
                   hdr.co_gtrinh_02c
            FROM rcv_tkhai_hdr hdr,
                 rcv_map_tkhai tkhai
            WHERE (hdr.loai_tkhai = tkhai.ma_tkhai)
              AND (hdr.da_nhan IS NULL)
              AND (hdr.khoa_so IS NULL)
            ORDER BY hdr.id;
        vc_Insert_Header_TKhai c_Insert_Header_TKhai%ROWTYPE;
        vr_Record_Hdr Record_Hdr;
        vr_Record_Dtnt Record_Dtnt;
        v_TKhai_Exits_Id NUMBER(10);
        v_Tthai_Tkhai VARCHAR2(1);

        CURSOR c_Ky_Khoa_So IS
            SELECT MAX(kylb_tu_ngay)
            FROM qlt_sothue_lock
            WHERE (loai_so = 'ST1B');
        v_Ky_Khoa_So DATE := '01-jan-1980';
    BEGIN
        OPEN c_Ky_Khoa_So;
        FETCH c_Ky_Khoa_So INTO v_Ky_Khoa_So;
        CLOSE c_Ky_Khoa_So;

        FOR vc_Insert_Header_TKhai IN c_Insert_Header_TKhai LOOP
            vr_Record_Hdr.id := vc_Insert_Header_TKhai.id;
            vr_Record_Hdr.tin := vc_Insert_Header_TKhai.tin;
            vr_Record_Hdr.ten_dtnt := vc_Insert_Header_TKhai.ten_dtnt;
            vr_Record_Hdr.dia_chi := vc_Insert_Header_TKhai.dia_chi;
            vr_Record_Hdr.loai_tkhai := vc_Insert_Header_TKhai.loai_tkhai;
            vr_Record_Hdr.loai := vc_Insert_Header_TKhai.loai;
            vr_Record_Hdr.ngay_nop := vc_Insert_Header_TKhai.ngay_nop;
            vr_Record_Hdr.kylb_tu_ngay := vc_Insert_Header_TKhai.kylb_tu_ngay;
            vr_Record_Hdr.kylb_den_ngay := vc_Insert_Header_TKhai.kylb_den_ngay;
            vr_Record_Hdr.kykk_tu_ngay := vc_Insert_Header_TKhai.kykk_tu_ngay;
            vr_Record_Hdr.kykk_den_ngay := vc_Insert_Header_TKhai.kykk_den_ngay;
            vr_Record_Hdr.ngay_cap_nhat := vc_Insert_Header_TKhai.ngay_cap_nhat;
            vr_Record_Hdr.nguoi_cap_nhat := vc_Insert_Header_TKhai.nguoi_cap_nhat;
            vr_Record_Hdr.co_loi_ddanh := vc_Insert_Header_TKhai.co_loi_ddanh;
            vr_Record_Hdr.so_hieu_tep := vc_Insert_Header_TKhai.so_hieu_tep;
            vr_Record_Hdr.so_tt_tk := vc_Insert_Header_TKhai.so_tt_tk;
            vr_Record_Hdr.ghi_chu_loi := vc_Insert_Header_TKhai.ghi_chu_loi;
            vr_Record_Hdr.co_gtrinh_02a := vc_Insert_Header_TKhai.co_gtrinh_02a;
            vr_Record_Hdr.co_gtrinh_02b := vc_Insert_Header_TKhai.co_gtrinh_02b;
            vr_Record_Hdr.co_gtrinh_02c := vc_Insert_Header_TKhai.co_gtrinh_02c;

            --Kiem tra da khoa so chua
            IF (v_Ky_Khoa_So < vr_Record_Hdr.kylb_tu_ngay) THEN
                --Neu chua khoa so
                --Lay thong tin DTNT
                Prc_Thong_Tin_Dtnt(vr_Record_Hdr.tin, vr_Record_Dtnt);
                --Kiem tra to khai da ton tai trong ky ke khai chua
                v_TKhai_Exits_Id := Fnc_TKhai_Exits(vr_Record_Hdr.tin,
                                                    vr_Record_Hdr.loai_tkhai,
                                                    vr_Record_Hdr.kykk_tu_ngay,
                                                    vr_Record_Hdr.kykk_den_ngay,
                                                    v_Tthai_Tkhai,
                                                    vr_Record_Hdr.loai);
                --Neu la to khai
                IF (vr_Record_Hdr.loai = 'TK') THEN
                    IF (vr_Record_Hdr.loai_tkhai = '14') THEN
                        --To khai GTGT
                        Prc_TKhai_GTGT(vr_Record_Hdr,
                                       vr_Record_Dtnt,
                                       v_TKhai_Exits_Id,
                                       v_Tthai_Tkhai);
                    ELSIF (vr_Record_Hdr.loai_tkhai = '26') THEN
                        --To khai TNDN quy
                        Prc_TKhai_TNDN_Quy(vr_Record_Hdr,
                                           vr_Record_Dtnt,
                                           v_TKhai_Exits_Id,
                                           v_Tthai_Tkhai);
                    END IF;
                --Neu la quyet toan
                ELSIF (vr_Record_Hdr.loai = 'QT') THEN
                    IF (vr_Record_Hdr.loai_tkhai = '05') THEN
                        --To khai quyet toan TNDN nam
                        Prc_TKhai_QToan_TNDN_Nam(vr_Record_Hdr,
                                                 vr_Record_Dtnt,
                                                 v_TKhai_Exits_Id,
                                                 v_Tthai_Tkhai);
                    END IF;
                END IF;
            ELSE
                --Neu da khoa so
                UPDATE rcv_tkhai_hdr
                SET khoa_so = 'Y'
                WHERE (id = vr_Record_Hdr.id);
            END IF;

            COMMIT;
        END LOOP;
    END;
END;
/


-- End of DDL Script for Package Body QLT_OWNER.RCV_PCK_CHUYEN_DLIEU_QLT

