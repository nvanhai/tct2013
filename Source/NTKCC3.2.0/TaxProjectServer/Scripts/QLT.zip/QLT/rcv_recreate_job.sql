BEGIN
    rcv_pck_job.prc_run_job('rcv_pck_job.prc_recreate_job;');
END;
/
