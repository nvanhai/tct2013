-- Start of DDL Script for Table QLT_OWNER.RCV_MAP_TKHAI
-- Generated 20-Feb-2006 10:13:46 from QLT_OWNER@QLT_91

CREATE TABLE rcv_map_tkhai
    (ma_tkhai                       VARCHAR2(2) NOT NULL,
    ma_tkhai_qlt                   VARCHAR2(2) NOT NULL,
    ghi_chu                        VARCHAR2(100),
    loai                           VARCHAR2(2) NOT NULL)
/

-- Constraints for RCV_MAP_TKHAI

ALTER TABLE rcv_map_tkhai
ADD CONSTRAINT rcv_map_tkhai_pk PRIMARY KEY (ma_tkhai)
USING INDEX
/


-- End of DDL Script for Table QLT_OWNER.RCV_MAP_TKHAI

