DELETE FROM rcv_map_ctieu
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','63','C',366,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','64','C',367,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','65','C',368,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','66','C',369,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','67','C',370,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','68','C',371,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','10','N',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','15','N',184,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','16','N',185,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','17','N',186,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','18','N',187,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','19','N',188,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','20','N',189,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','21','N',190,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','22','N',191,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','23','N',192,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','24','N',193,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','25','N',194,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','26','N',195,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','27','N',196,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','1','C',170,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','2','D',171,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','3','C',172,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','4','C',173,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','5','C',174,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','6','C',175,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','7','N',176,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','8','N',177,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','9','D',178,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','10','N',179,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','11','D',180,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','12','N',181,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','13','D',182,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','1','C',197,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','2','C',198,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','3','C',199,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','4','C',200,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','5','C',201,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','6','C',202,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','7','C',203,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','8','C',204,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','9','C',205,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','10','D',206,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','11','N',207,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','12','N',208,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','13','D',209,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','14','N',210,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','15','D',211,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','16','N',212,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','17','D',213,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','18','N',214,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','19','N',215,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','20','N',216,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','21','N',217,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','22','N',218,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','23','N',219,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','24','N',220,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','25','N',221,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','26','N',222,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','27','N',223,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','28','N',224,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','29','N',225,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','30','N',226,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0306','31','N',227,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','1','C',228,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','2','C',229,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','3','C',230,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','4','C',231,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','5','C',232,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','6','C',233,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','7','C',234,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','8','C',235,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','9','C',236,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','10','C',237,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','11','N',238,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','12','N',239,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','13','N',240,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','14','N',241,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','15','N',242,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0307','16','N',243,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','1','C',244,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','2','D',245,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','3','C',246,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','4','D',247,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','5','C',248,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','6','D',249,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','7','C',250,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','8','C',251,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','9','C',252,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','10','C',253,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','11','N',254,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','12','N',255,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','13','N',256,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','14','N',257,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0308','15','N',258,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','1','C',259,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','2','C',260,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','3','D',261,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','4','C',262,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','5','D',263,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','6','D',264,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','7','C',265,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','8','C',266,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','9','D',267,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','10','C',268,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','11','D',269,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','12','D',270,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','13','C',271,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','14','C',272,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','15','N',273,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','16','N',274,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','17','N',275,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','18','N',276,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','19','N',277,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0309','20','N',278,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0310','1','C',279,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0310','2','C',280,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0310','3','N',281,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0310','4','N',282,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0310','5','N',283,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0310','6','N',284,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0310','7','N',285,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0310','8','N',286,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','1','C',287,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','2','C',288,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','3','D',289,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','4','N',290,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','5','N',291,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','6','N',292,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','7','C',293,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','8','C',294,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','9','D',295,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','10','C',296,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','11','C',297,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','12','N',298,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','13','N',299,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','14','N',300,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0311','15','N',301,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','1','C',302,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','2','C',303,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','3','C',304,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','4','C',305,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','5','N',306,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','6','N',307,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','7','N',308,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','8','N',309,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','9','N',310,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0312','10','N',311,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','1','C',312,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','2','C',313,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','3','C',314,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','4','N',315,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','5','N',316,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','6','N',317,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','7','C',318,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','8','D',319,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','9','C',320,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','10','N',321,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','11','N',322,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','12','N',323,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','13','N',324,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','14','N',325,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0313','15','N',326,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','1','C',327,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','2','C',328,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','3','C',329,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','4','D',330,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','5','C',331,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','6','C',332,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','7','N',333,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','8','D',334,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','9','C',335,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','10','N',336,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','11','D',337,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','12','C',338,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','13','C',339,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','14','C',340,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','15','C',341,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','16','C',342,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','17','C',343,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','18','D',344,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','19','C',345,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','20','N',346,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','21','N',347,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','22','D',348,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','23','N',349,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','24','D',350,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','25','N',351,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','26','N',352,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','27','N',353,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','28','N',354,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0314','29','N',355,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','1','C',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','2','N',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','3','N',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','4','N',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','5','N',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','6','N',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','7','N',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','8','N',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0315','9','N',356,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0305','14','N',183,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','3','N',3,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','4','N',4,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','5','N',5,'[12]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','7','N',6,'[14]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','9','N',7,'[16]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','11','N',8,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','12','N',9,'[18]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','14','N',10,'[20]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','18','N',13,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','19','N',14,'[24]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','21','N',15,'[26]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','22','N',16,'[27]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','24','N',17,'[29]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','25','N',18,'[30]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','27','N',19,'[32]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','29','N',20,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','30','N',21,'[34]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','32','N',22,'[36]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','34','N',23,'[38]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','36','N',24,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','2','N',2,'[11]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','6','N',5,'[13]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','8','N',6,'[15]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','10','N',7,'[17]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','13','N',9,'[19]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','15','N',10,'[21]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','16','N',11,'[22]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','17','N',12,'[23]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','20','N',14,'[25]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','23','N',16,'[28]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','26','N',18,'[31]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','28','N',19,'[33]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','31','N',21,'[35]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','33','N',22,'[37]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','35','N',23,'[39]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','37','N',25,'[40]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','38','N',26,'[41]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','39','N',27,'[42]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','40','N',28,'[43]')
/
INSERT INTO rcv_map_ctieu
VALUES
('0102','1','N',29,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0102','8','C',29,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','11','N',54,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0102','2','D',29,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0102','3','N',29,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0102','4','N',29,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0102','5','N',29,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0102','6','N',29,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0102','7','C',29,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0103','2','N',36,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0103','3','N',37,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0103','4','N',38,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0103','5','N',39,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0103','6','N',40,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0103','1','N',35,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0103','7','N',41,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0103','8','N',42,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','1','N',43,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','2','N',44,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','3','N',45,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','4','N',46,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','5','N',47,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','6','N',48,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','7','N',49,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','8','N',50,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','9','N',51,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0104','10','N',52,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0103','9','N',53,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0201','1','N',357,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0201','2','N',358,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0201','3','N',359,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0201','4','N',360,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0201','5','N',361,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0201','6','N',362,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0201','7','N',363,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0201','8','N',364,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0201','9','N',365,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','1','N',55,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','2','N',56,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','3','N',57,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','4','N',58,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','5','N',59,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','6','N',60,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','7','N',61,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','8','N',62,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','9','N',63,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','10','N',64,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','11','N',65,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','12','N',66,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','13','N',67,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','14','N',68,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','15','N',69,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','16','N',70,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','17','N',71,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','18','N',72,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','19','N',73,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','20','N',74,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','21','N',75,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','22','N',76,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','23','N',77,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0101','1','N',1,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','24','N',78,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','25','N',79,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','26','N',80,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','27','N',81,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','28','N',82,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','29','N',83,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','30','N',84,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','31','N',85,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','32','N',86,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','33','N',87,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','34','N',88,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','35','N',89,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','36','N',90,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','37','N',91,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','38','N',92,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','39','N',93,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','40','N',94,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','41','N',95,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','42','N',96,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','43','N',97,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','44','N',98,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','45','N',99,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','46','N',100,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','47','N',101,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','48','N',102,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','49','N',103,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','50','N',104,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','51','N',105,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','52','N',106,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','53','N',107,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','54','N',108,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','55','N',109,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','56','N',110,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','57','N',111,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','58','N',112,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','59','N',113,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','60','N',114,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','61','N',115,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0301','62','N',116,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','1','N',119,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','2','N',120,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','3','N',121,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','4','N',122,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','5','N',123,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','6','N',124,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','7','N',125,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','8','N',126,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','9','N',127,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0303','10','N',128,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','31','N',159,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','32','N',160,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','33','N',161,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','34','N',162,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','35','N',163,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','36','N',164,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','37','N',165,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','38','N',166,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','39','N',167,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','40','N',168,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','41','N',169,'B')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','1','C',129,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','2','C',130,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','3','C',131,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','4','C',132,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','5','C',133,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','6','C',134,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','7','C',135,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','8','C',136,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','9','C',137,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','10','C',138,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','11','C',139,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','12','C',140,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','13','C',141,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','14','C',142,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','15','C',143,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','16','N',144,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','17','C',145,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','18','N',146,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','19','N',147,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','20','C',148,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','21','C',149,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','22','C',150,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','23','C',151,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','24','N',152,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','25','N',153,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','26','D',154,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','27','N',155,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','28','D',156,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','29','N',157,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','30','D',158,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','1','N',117,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','57','N',118,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','9','N',372,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','17','N',373,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','25','N',374,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','33','N',375,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','62','N',376,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','67','N',377,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','72','N',378,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','77','N',379,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','41','N',380,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','49','N',381,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','2','N',117,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','58','N',118,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','10','N',372,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','18','N',373,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','26','N',374,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','34','N',375,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','63','N',376,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','68','N',377,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','73','N',378,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','78','N',379,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','42','N',380,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','50','N',381,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','3','N',117,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','59','N',118,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','11','N',372,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','19','N',373,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','27','N',374,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','35','N',375,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','64','N',376,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','69','N',377,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','74','N',378,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','79','N',379,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','43','N',380,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','51','N',381,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','4','N',117,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','60','N',118,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','12','N',372,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','20','N',373,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','28','N',374,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','36','N',375,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','65','N',376,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','70','N',377,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','75','N',378,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','80','N',379,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','44','N',380,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','52','N',381,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','5','N',117,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','61','N',118,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','13','N',372,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','21','N',373,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','29','N',374,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','37','N',375,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','66','N',376,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','71','N',377,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','76','N',378,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','81','N',379,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','45','N',380,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','53','N',381,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','6','N',117,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','14','N',372,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','22','N',373,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','30','N',374,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','38','N',375,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','46','N',380,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','54','N',381,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','7','N',117,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','15','N',372,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','23','N',373,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','31','N',374,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','39','N',375,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','47','N',380,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','55','N',381,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','8','N',117,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','16','N',372,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','24','N',373,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','32','N',374,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','40','N',375,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','48','N',380,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0302','56','N',381,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','1','N',382,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','9','N',383,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','17','N',384,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','25','N',385,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','33','N',386,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','41','N',387,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','49','N',388,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','57','N',389,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','62','N',390,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','67','N',391,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','72','N',392,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','77','N',393,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','2','N',382,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','10','N',383,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','18','N',384,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','26','N',385,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','34','N',386,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','42','N',387,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','50','N',388,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','58','N',389,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','63','N',390,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','68','N',391,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','73','N',392,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','78','N',393,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','3','N',382,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','11','N',383,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','19','N',384,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','27','N',385,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','35','N',386,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','43','N',387,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','51','N',388,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','59','N',389,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','64','N',390,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','69','N',391,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','74','N',392,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','79','N',393,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','4','N',382,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','12','N',383,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','20','N',384,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','28','N',385,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','36','N',386,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','44','N',387,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','52','N',388,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','60','N',389,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','65','N',390,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','70','N',391,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','75','N',392,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','80','N',393,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','5','N',382,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','13','N',383,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','21','N',384,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','29','N',385,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','37','N',386,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','45','N',387,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','53','N',388,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','61','N',389,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','66','N',390,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','71','N',391,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','76','N',392,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','81','N',393,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','6','N',382,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','14','N',383,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','22','N',384,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','30','N',385,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','38','N',386,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','46','N',387,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','54','N',388,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','7','N',382,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','15','N',383,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','23','N',384,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','31','N',385,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','39','N',386,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','47','N',387,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','55','N',388,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','8','N',382,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','16','N',383,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','24','N',384,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','32','N',385,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','40','N',386,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','48','N',387,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0316','56','N',388,NULL)
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','42','C',394,'A')
/
INSERT INTO rcv_map_ctieu
VALUES
('0304','43','C',395,'A')
/
