Spool C:\Temp\Log_NTK_324_DML.txt
/
Whenever sqlerror continue
/
PROM '===== INSERT - UPDATE ====='
Prompt 1_RCV_DM_TKHAI_BLP.sql
@@1_RCV_DM_TKHAI_BLP.sql;
Prompt 3_RCV_GDIEN_TKHAI_BLP.sql
@@3_RCV_GDIEN_TKHAI_BLP.sql;
Prompt 4_RCV_MAP_CTIEU_BLP.sql
@@4_RCV_MAP_CTIEU_BLP.sql;
Prompt 5_update_cg_reg_code.sql
@@5_update_cg_reg_code.sql;
/
Exit
/