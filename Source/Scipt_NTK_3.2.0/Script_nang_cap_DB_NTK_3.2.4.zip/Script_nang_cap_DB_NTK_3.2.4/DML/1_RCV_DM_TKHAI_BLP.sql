--01_TBAC_BLP
INSERT INTO QLT_NTK.RCV_DM_TKHAI (MA, TEN, KIEU_KY, PHIEN_BAN, START_DATE, END_DATE) VALUES ('01_TBAC_BLP', 'Th�ng b�o ph�t h�nh bi�n lai thu ph�, l� ph�', 'D', '324', '01-JAN-2010', null);
--03_TBAC_BLP
INSERT INTO QLT_NTK.RCV_DM_TKHAI (MA, TEN, KIEU_KY, PHIEN_BAN, START_DATE, END_DATE) VALUES ('03_TBAC_BLP', 'Th�ng b�o k�t qu� h�y bi�n lai thu ph�, l� ph�', 'D', '324', '01-JAN-2010', null);
--BC21_AC_BLP
INSERT INTO QLT_NTK.RCV_DM_TKHAI (MA, TEN, KIEU_KY, PHIEN_BAN, START_DATE, END_DATE) VALUES ('BC21_AC_BLP', 'B�o c�o m�t, ch�y, h�ng bi�n lai thu ph�, l� ph�', 'D', '324', '01-JAN-2010', null);
--01_AC_BLP
INSERT INTO QLT_NTK.RCV_DM_TKHAI (MA, TEN, KIEU_KY, PHIEN_BAN, START_DATE, END_DATE) VALUES ('01_AC_BLP', 'B�o c�o t�nh h�nh nh�n in h�a ��n', 'Y', '324', '01-JAN-2010', null);
--BC26_AC
INSERT INTO QLT_NTK.RCV_DM_TKHAI (MA, TEN, KIEU_KY, PHIEN_BAN, START_DATE, END_DATE) VALUES ('BC26_AC_BLP', 'B�o c�o t�nh h�nh s� d�ng bi�n lai thu ph�, l� ph�', 'Q', '324', '01-JAN-2009', null);

COMMIT;
