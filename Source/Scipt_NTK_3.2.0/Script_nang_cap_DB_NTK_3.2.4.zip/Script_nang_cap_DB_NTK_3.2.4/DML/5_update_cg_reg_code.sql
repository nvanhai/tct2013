update QLT_OWNER.cg_ref_codes  set rv_low_value = '3.2.4' where rv_domain = 'HTKK_ABOUT.VERSION' and rv_low_value ='3.2.3';
commit;