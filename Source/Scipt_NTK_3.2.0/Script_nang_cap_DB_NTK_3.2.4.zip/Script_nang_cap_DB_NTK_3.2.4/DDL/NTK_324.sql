spool C:\Temp\Log_NTK_324_DDL.txt
/
Whenever sqlerror continue
/
PROM '===== ALTER - CREATE ====='
Prompt 6_SCRIPT_VIEW_BLP.sql
@@6_SCRIPT_VIEW_BLP.sql;
Exit
/